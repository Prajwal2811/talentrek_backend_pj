<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jobseeker_or_expat_assessment_status', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('jobseeker_or_expat_id');
            $table->enum('role', ['jobseeker', 'expat'])->nullable();
            $table->unsignedBigInteger('assessment_id');
            $table->unsignedBigInteger('material_id');
            $table->boolean('submitted')->default(false);
            $table->string('score')->nullable();
            $table->string('total')->nullable();
            $table->string('percentage')->nullable();
            $table->string('result_status')->nullable();
            $table->timestamps();
            // $table->unique(['jobseeker_id', 'assessment_id'], 'js_assess_status_unique');
        });

    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jobseeker_assessment_status');
    }
};
