@include('admin.componants.header')

<body data-theme="light">
    <div id="body" class="theme-cyan">
        <div class="themesetting">
        </div>
        <div class="overlay"></div>
        <div id="wrapper">
            @include('admin.componants.navbar')
            @include('admin.componants.sidebar')
            <div id="main-content">
                <div class="container-fluid">
                    @include('admin.errors')
                    <div class="block-header">
                        <div class="row clearfix align-items-center">
                            <!-- Left Column -->
                            <div class="col-xl-10 col-md-10 col-sm-12">
                                <h1>Hi, {{  Auth()->user()->name }}!</h1>
                                <span>JustDo Jobseeker's Profile</span>
                            </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12">
                            <div class="card social theme-bg">
                                <div class="profile-header d-flex justify-content-between justify-content-center">
                                    <div class="d-flex">
                                        <div class="mr-3">
                                            <img src="../assets/images/user.png" class="rounded" alt="">
                                        </div>
                                        <!-- <div class="details">
                                            <h4 class="mb-0">{{ $jobseeker->name }}</h4>
                                            <span class="text-light">{{ $jobseeker->city }}</span> -->
                                            <!-- <p class="mb-0"><span>Posts: <strong>321</strong></span> <span>Followers: <strong>4,230</strong></span> <span>Following: <strong>560</strong></span></p> -->
                                        <!-- </div> -->

                                         <div class="flex justify-between items-center">
                                            <div class="details">
                                                <h4 class="mb-0">{{ $jobseeker->name }}</h4>
                                                <span class="text-light">{{ $jobseeker->city }}</span>
                                                <!-- <p class="mb-0"><span>Posts: <strong>321</strong></span> <span>Followers: <strong>4,230</strong></span> <span>Following: <strong>560</strong></span></p> -->
                                            </div>
                                            <a href="{{ route('admin.jobseeker.resume.download', $jobseeker->id) }}"
                                            class="ml-4 bg-green-600 text-white px-3 py-1.5 rounded-md text-sm hover:bg-green-700">
                                                Download Resume
                                            </a>
                                        </div>
                                    </div>
                                    <div>
                                        @php
                                            $status = $jobseeker->admin_status;
                                            $userRole = auth()->user()->role;
                                        @endphp

                                        {{-- Admin Actions --}}
                                        @if(!$status && $userRole === 'admin')
                                            <button class="btn btn-default me-2" data-bs-toggle="modal" data-bs-target="#approveModal">Approve</button>
                                            <button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#rejectModal">Reject</button>

                                        {{-- Superadmin Actions --}}
                                        @elseif($userRole === 'superadmin')

                                            {{-- Admin has not yet acted --}}
                                            @if(!$status)
                                                <span class="badge bg-warning me-2">Admin has not yet responded</span>

                                            {{-- Admin has rejected — Superadmin cannot override --}}
                                            @elseif($status === 'rejected')
                                                <div class="d-flex flex-column align-items-end text-end">
                                                    <span class="badge bg-danger mb-2">Admin Rejected</span>
                                                    <p class="text-light m-0">
                                                        <strong>Superadmin action not allowed</strong> because the profile was rejected by Admin.
                                                    </p>
                                                </div>


                                            {{-- Admin approved — Superadmin can act if not already acted --}}
                                            @elseif($status === 'approved')
                                                <span class="badge bg-info me-2">Admin Approved</span>
                                                <button class="btn btn-default me-2" data-bs-toggle="modal" data-bs-target="#superApproveModal">Super Approve</button>
                                                <button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#superRejectModal">Super Reject</button>

                                            {{-- Superadmin already acted --}}
                                            @elseif(Str::startsWith($status, 'superadmin_'))
                                                @php
                                                    $badgeClass = Str::contains($status, 'approved') ? 'success' : 'danger';
                                                    $statusLabel = ucfirst(str_replace('_', ' ', $status));
                                                @endphp
                                                <span class="badge bg-{{ $badgeClass }}">{{ $statusLabel }}</span>
                                            @endif

                                        {{-- Final decision already made --}}
                                        @elseif(Str::startsWith($status, 'superadmin_'))
                                            @php
                                                $badgeClass = Str::contains($status, 'approved') ? 'success' : 'danger';
                                                $statusLabel = ucfirst(str_replace('_', ' ', $status));
                                            @endphp
                                            <span class="badge bg-{{ $badgeClass }}">{{ $statusLabel }}</span>

                                        {{-- Admin view-only state --}}
                                        @else
                                            <span class="badge bg-secondary">{{ ucfirst($status) }}</span>
                                        @endif


                                        <!-- Admin Approve Modal -->
                                        <div class="modal fade text-dark" id="approveModal" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header"><h5 class="modal-title">Confirm Approval</h5></div>
                                                    <div class="modal-body">Are you sure you want to approve this profile?</div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button class="btn btn-success" onclick="updateStatus({{ $jobseeker->id }}, 'approved', this)">Yes, Approve</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Admin Reject Modal -->
                                        <div class="modal fade text-dark" id="rejectModal" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header"><h5 class="modal-title">Confirm Rejection</h5></div>
                                                    <div class="modal-body">
                                                        <p>Are you sure you want to reject this profile?</p>
                                                        <div class="form-group">
                                                            <label for="adminRejectionReason">Reason:</label>
                                                            <textarea required id="adminRejectionReason" class="form-control" rows="3" placeholder="Enter reason..."></textarea>
                                                            <small id="adminRejectionReasonError" class="text-danger d-none"></small>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button class="btn btn-danger" onclick="submitRejection({{ $jobseeker->id }}, 'rejected', 'adminRejectionReason', this)">Yes, Reject</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Superadmin Approve Modal -->
                                        <div class="modal fade text-dark" id="superApproveModal" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header"><h5 class="modal-title">Confirm Super Approval</h5></div>
                                                    <div class="modal-body">Are you sure you want to super approve this profile?</div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button class="btn btn-success" onclick="updateStatus({{ $jobseeker->id }}, 'superadmin_approved', this)">Yes, Approve</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Superadmin Reject Modal -->
                                        <div class="modal fade text-dark" id="superRejectModal" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header"><h5 class="modal-title">Confirm Super Rejection</h5></div>
                                                    <div class="modal-body">
                                                        <p>Are you sure you want to super reject this profile?</p>
                                                        <div class="form-group">
                                                            <label for="superRejectionReason">Reason:</label>
                                                            <textarea required id="superRejectionReason" class="form-control" rows="3" placeholder="Enter reason..."></textarea>
                                                            <small id="superRejectionReasonError" class="text-danger d-none"></small>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button class="btn btn-danger" onclick="submitRejection({{ $jobseeker->id }}, 'superadmin_rejected', 'superRejectionReason', this)">Yes, Reject</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- JS -->
                                        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                                        <script>
                                            function updateStatus(jobseekerId, status, btn) {
                                                const originalText = btn.innerHTML;
                                                btn.disabled = true;
                                                btn.innerHTML = `<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Processing...`;

                                                $.post('{{ route("admin.jobseeker.updateStatus") }}', {
                                                    _token: '{{ csrf_token() }}',
                                                    jobseeker_id: jobseekerId,
                                                    status: status
                                                }).done(() => {
                                                    $('.modal').modal('hide');
                                                    location.reload();
                                                }).fail(() => {
                                                    btn.disabled = false;
                                                    btn.innerHTML = originalText;
                                                });
                                            }

                                            function submitRejection(jobseekerId, status, reasonId, btn) {
                                                const reason = document.getElementById(reasonId).value.trim();
                                                const errorDiv = document.getElementById(reasonId + "Error");

                                                if (!reason) {
                                                    if (errorDiv) {
                                                        errorDiv.textContent = "Reason is required for rejection.";
                                                        errorDiv.classList.remove("d-none");
                                                    }
                                                    return;
                                                } else {
                                                    if (errorDiv) errorDiv.classList.add("d-none");
                                                }

                                                const originalText = btn.innerHTML;
                                                btn.disabled = true;
                                                btn.innerHTML = `<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Processing...`;

                                                $.post('{{ route("admin.jobseeker.updateStatus") }}', {
                                                    _token: '{{ csrf_token() }}',
                                                    jobseeker_id: jobseekerId,
                                                    status: status,
                                                    reason: reason
                                                }).done(() => {
                                                    $('.modal').modal('hide');
                                                    location.reload();
                                                }).fail((xhr) => {
                                                    btn.disabled = false;
                                                    btn.innerHTML = originalText;

                                                    if (errorDiv && xhr.responseJSON?.message) {
                                                        errorDiv.textContent = xhr.responseJSON.message;
                                                        errorDiv.classList.remove("d-none");
                                                    }
                                                });
                                            }
                                        </script>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-5">
                            <div class="card" style="position: sticky; top: 100px;">
                                <div class="header">
                                    <h2>Basic Information</h2>
                                </div>
                                <div class="body">
                                    <form>
                                        <div class="row">
                                            <div class="col-md-12 form-group">
                                                <label>Name</label>
                                                <input readonly type="text" class="form-control" value="{{ $jobseeker->name }}">
                                            </div>
                                            <div class="col-md-12 form-group">
                                                <label>Gender</label>
                                                <input readonly type="text" class="form-control" value="{{ $jobseeker->gender }}">
                                            </div>
                                            <div class="col-md-12 form-group">
                                                <label>Email address</label>
                                                <input readonly type="text" class="form-control" value="{{ $jobseeker->email }}">
                                            </div>
                                            <!-- <div class="col-md-12 form-group">
                                                <label>Date of birth</label>
                                                @php
                                                    $date = \Carbon\Carbon::parse($jobseeker->date_of_birth);
                                                    $day = $date->format('j');
                                                    $suffix = match (true) {
                                                        $day % 100 >= 11 && $day % 100 <= 13 => 'th',
                                                        $day % 10 == 1 => 'st',
                                                        $day % 10 == 2 => 'nd',
                                                        $day % 10 == 3 => 'rd',
                                                        default => 'th',
                                                    };
                                                    $formattedDate = $day . $suffix . ' ' . $date->format('F Y');
                                                @endphp
                                                <input readonly type="text" class="form-control" value="{{ $formattedDate }}">
                                            </div> -->
                                            <div class="col-md-12 form-group">
                                                <label>Date of birth</label>
                                                @php
                                                    $formattedDate = '';
                                                    if (!empty($jobseeker->date_of_birth)) {
                                                        $date = \Carbon\Carbon::parse($jobseeker->date_of_birth);
                                                        $day = $date->format('j');
                                                        $suffix = match (true) {
                                                            $day % 100 >= 11 && $day % 100 <= 13 => 'th',
                                                            $day % 10 == 1 => 'st',
                                                            $day % 10 == 2 => 'nd',
                                                            $day % 10 == 3 => 'rd',
                                                            default => 'th',
                                                        };
                                                        $formattedDate = $day . $suffix . ' ' . $date->format('F Y');
                                                    }
                                                @endphp

                                                <input readonly type="text" class="form-control" 
                                                    value="{{ $formattedDate ?: '' }}">
                                            </div>
                                            <div class="col-md-12 form-group">
                                                <label>Phone number</label>
                                                <input readonly type="text" class="form-control" value="{{ $jobseeker->phone_code ? $jobseeker->phone_code . '-' . $jobseeker->phone_number : $jobseeker->phone_number }}">
                                            </div>
                                            
                                            <div class="col-md-12 form-group">
                                                <label>City</label>
                                                <input readonly type="text" class="form-control" value="{{ $jobseeker->city }}">
                                            </div>

                                            <div class="col-md-12 form-group">
                                                <label>State</label>
                                                <input readonly type="text" class="form-control" value="{{ $jobseeker->state }}">
                                            </div>

                                            <div class="col-md-12 form-group">
                                                <label>Pin Code</label>
                                                <input readonly type="text" class="form-control" value="{{ $jobseeker->pin_code }}">
                                            </div>

                                            <div class="col-md-12 form-group">
                                                <label>Country</label>
                                                <input readonly type="text" class="form-control" value="{{ $jobseeker->country }}">
                                            </div>
                                            <div class="col-md-12 form-group">
                                                <label>Address</label>
                                                <textarea readonly class="form-control">{{ $jobseeker->address }}</textarea>
                                            </div>


                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8 col-md-7">
                            <div class="card">
                                <div class="header">
                                    <h2>Personal Information</h2>
                                        <div class="body">
                                            <!-- Tab navigation -->
                                            <ul class="nav nav-tabs2 mb-4" role="tablist">
                                                <li class="nav-item">
                                                    <a class="nav-link active" data-toggle="tab" href="#education">Educational Details</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-toggle="tab" href="#work">Work Experience</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-toggle="tab" href="#skills">Skills & Training</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-toggle="tab" href="#additional">Additional Information</a>
                                                </li>
                                            </ul>

                                            <!-- Tab content -->
                                            <div class="tab-content">

                                                <!-- Education -->
                                                <div class="tab-pane show active" id="education">
                                                    <form>
                                                        @if ($educations->isEmpty())
                                                            <p class="text-muted">No educational details found.</p>
                                                        @else
                                                            @foreach ($educations as $index => $education)
                                                                <div class="row">
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Highest qualification</label>
                                                                        <input readonly type="text" class="form-control" value="{{ $education->high_education }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Field of study</label>
                                                                        <input readonly type="text" class="form-control" value="{{ $education->field_of_study }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Institution name</label>
                                                                        <input readonly type="text" class="form-control" value="{{ $education->institution }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Graduation year</label>
                                                                        <input readonly type="text" class="form-control" value="{{ $education->graduate_year }}">
                                                                    </div>
                                                                </div>
                                                                @if (!$loop->last)
                                                                    <hr>
                                                                @endif
                                                            @endforeach
                                                        @endif
                                                    </form>
                                                </div>

                                                <!-- Work Experience -->
                                                <div class="tab-pane fade" id="work">
                                                    <form>
                                                        @if ($experiences->isEmpty())
                                                            <p class="text-muted">No work experience found.</p>
                                                        @else
                                                            @foreach ($experiences as $experience)
                                                                <div class="row">
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Job role</label>
                                                                        <input type="text" class="form-control" readonly value="{{ $experience->job_role }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Organization</label>
                                                                        <input readonly type="text" class="form-control" value="{{ $experience->organization }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Started from</label>
                                                                        <input readonly type="text" class="form-control" value="{{ \Carbon\Carbon::parse($experience->starts_from)->format('jS F Y') }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>To</label>
                                                                        <input readonly type="text" class="form-control" value="{{ $experience->end_to === 'work here' ? 'Work Here' : \Carbon\Carbon::parse($experience->end_to)->format('jS F Y') }}">
                                                                    </div>
                                                                </div>
                                                                @if (!$loop->last)
                                                                    <hr>
                                                                @endif
                                                            @endforeach
                                                        @endif
                                                    </form>
                                                </div>

                                                <!-- Skills -->
                                                <div class="tab-pane fade" id="skills">
                                                    <form>
                                                        @if ($skills->isEmpty())
                                                            <p class="text-muted">No skills or training details found.</p>
                                                        @else
                                                            @foreach ($skills as $skill)
                                                                <div class="row">
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Skills</label>
                                                                        <input readonly type="text" class="form-control" value="{{ $skill->skills }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Area of interests</label>
                                                                        <input readonly type="text" class="form-control" value="{{ $skill->interest }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Job categories</label>
                                                                        <input readonly type="text" class="form-control" value="{{ $skill->job_category }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Website link</label>
                                                                        <input readonly type="url" class="form-control" value="{{ $skill->website_link }}">
                                                                    </div>
                                                                    <div class="col-md-6 form-group">
                                                                        <label>Portfolio link</label>
                                                                        <input readonly type="url" class="form-control" value="{{ $skill->portfolio_link }}">
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        @endif
                                                    </form>
                                                </div>

                                                <!-- Additional Info -->
                                                <div class="tab-pane fade" id="additional">
                                                    <form>
                                                        @if ($additioninfos->isEmpty())
                                                            <p class="text-muted">No additional documents found.</p>
                                                        @else
                                                            <div class="row">
                                                                @foreach($additioninfos as $info)
                                                                    @if($info->doc_type == 'resume')
                                                                        <div class="col-md-12 form-group d-flex align-items-center">
                                                                            <label class="w-100">Uploaded Resume</label>
                                                                            <input readonly type="text" class="form-control me-2" value="{{ $info->document_name }}">
                                                                            <a href="{{ $info->document_path }}" target="_blank" class="btn btn-danger">View</a>
                                                                        </div>
                                                                    @elseif($info->doc_type == 'profile_picture')
                                                                        <div class="col-md-12 form-group d-flex align-items-center">
                                                                            <label class="w-100">Uploaded Profile Picture</label>
                                                                            <input readonly type="text" class="form-control me-2" value="{{ $info->document_name }}">
                                                                            <a href="{{ $info->document_path }}" target="_blank" class="btn btn-danger">View</a>
                                                                        </div>
                                                                    @endif
                                                                @endforeach
                                                            </div>
                                                        @endif
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                </div>
                            </div>


                            @php
                                use App\Models\JobseekerTrainingMaterialPurchase;

                                $courses = JobseekerTrainingMaterialPurchase::with(['material.reviews'])
                                                                            ->where('jobseeker_id', $jobseeker->id)
                                                                            ->get();

                                $trainerImage = App\Models\AdditionalInfo::where('doc_type', 'profile_picture')
                                                                        ->where('user_id', $jobseeker->id)
                                                                        ->first();
                            @endphp

                            <div class="card">
                                <div class="header">
                                    <h2>Jobseeker Trainings</h2>
                                </div>
                                <div class="body">
                                    <div class="col-lg-12">
                                        @forelse($courses as $index => $purchase)
                                            @php
                                                $material = $purchase->material;
                                                $reviews = $material->reviews ?? collect();
                                                $trainerName = App\Models\Trainers::where('id', $material->trainer_id)->value('name');
                                                $lessons = $material->lesson_count;
                                                $duration = $material->duration .'hrs';
                                                $level = $material->level;
                                                $rating = $material->rating ?? 4;
                                                $img = $material->thumbnail_file_path;
                                                $assingBatch = \App\Models\TrainingBatch::where('training_material_id', $material->id)
                                                                                        ->where('id', $purchase->batch_id)
                                                                                        ->first();
                                            @endphp

                                            <div class="card d-flex flex-row p-3 mb-3 {{ $index >= 1 ? 'd-none extra-course' : '' }}">
                                                <img src="{{ asset($img) }}" alt="{{ $material->training_title }}"
                                                    class="img-fluid rounded" style="width: 200px; object-fit: cover;">
                                                    <div class="ps-4 d-flex flex-column justify-content-between flex-grow-1">
                                                        <div>
                                                            <div class="d-flex justify-content-between align-items-center">
                                                            <h5 class="fw-bold mb-1 mb-0">{{ $material->training_title }}</h5>
                                                            @php
                                                                $batchStatus = strtolower($purchase->batchStatus); // e.g., 'pending', 'completed', 'in process'
                                                                $badgeClass = match($batchStatus) {
                                                                    'completed' => 'bg-success text-white',
                                                                    'pending' => 'bg-warning text-dark',
                                                                    'in process' => 'bg-info text-white',
                                                                    default => 'bg-secondary'
                                                                };
                                                            @endphp
                                                            <span class="badge {{ $badgeClass }} text-capitalize">
                                                                {{ $batchStatus }}
                                                            </span>
                                                        </div>
                                                            
                                                        <p class="text-muted mb-2">{{ $material->training_sub_title ?? 'No description available.' }}</p>
                                                        @php
                                                            $averageRating = $reviews->avg('ratings');
                                                            $roundedRating = round($averageRating);
                                                        @endphp


                                                        <div class="d-flex align-items-center mb-2">
                                                            <span class="text-warning me-1">
                                                                @for ($i = 1; $i <= 5; $i++)
                                                                    @if ($i <= $roundedRating)
                                                                        ★
                                                                    @else
                                                                        ☆
                                                                    @endif
                                                                @endfor
                                                            </span>
                                                            <span class="text-muted">
                                                                ({{ number_format($averageRating, 1) }}/5 from {{ $reviews->count() }} review{{ $reviews->count() === 1 ? '' : 's' }})
                                                            </span>
                                                        </div>
                                                    </div>
                                                        <div class="d-flex align-items-center justify-content-between mt-3">
                                                            <div class="d-flex align-items-center">
                                                                <img src="{{ $trainerImage->document_path }}" alt="{{ $trainerName }}"
                                                                    class="rounded-circle me-2" style="width: 35px;">
                                                                <span class="fw-semibold">{{ $trainerName }}</span>
                                                            </div>
                                                            <div class="d-flex align-items-center text-muted gap-3">
                                                            <div>
                                                                    <i data-feather="book-open" class="me-1"></i>
                                                                   @if(in_array($material->training_type, ['online', 'classroom']))
                                                                        @if($assingBatch)
                                                                            {{ $assingBatch->batch_no . ' (' . \Carbon\Carbon::parse($assingBatch->start_date)->format('d M, Y') . ')' }}
                                                                        @else
                                                                            <span class="text-danger">No Batch Assigned</span>
                                                                        @endif
                                                                    @else
                                                                        {{ $lessons }} lesson{{ $lessons != 1 ? 's' : '' }}
                                                                    @endif

                                                                </div>

                                                                <div><i data-feather="clock" class="me-1"></i>{{ $purchase->training_type }}</div>
                                                                <div><i data-feather="bar-chart-2" class="me-1"></i>{{ $level }}</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                        @empty
                                            <div class="alert alert-warning">No trainings purchased yet.</div>
                                        @endforelse

                                        @if($courses->count() > 1)
                                            <div class="text-center mt-4">
                                                <button class="btn btn-primary" onclick="toggleCourses(this)">View More</button>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>


                            <script>
                                function toggleCourses(button) {
                                    const extraCourses = document.querySelectorAll('.extra-course');
                                    extraCourses.forEach(el => el.classList.toggle('d-none'));
                                    button.textContent = button.textContent === 'View More' ? 'View Less' : 'View More';
                                }
                            </script>
                            <script>feather.replace();</script>



                            

                       @php
                            use Carbon\Carbon;

                            $mentorships = \App\Models\BookingSession::with([
                                'mentor.reviews', 'mentor.profilePicture', 'mentor.experiences'
                            ])->where('jobseeker_id', $jobseeker->id)
                            ->where('user_type', 'mentor')
                            ->whereHas('mentor.profilePicture')
                            ->get();

                            $assessments = \App\Models\BookingSession::with([
                                'assessor.reviews', 'assessor.profilePicture', 'assessor.experiences'
                            ])->where('jobseeker_id', $jobseeker->id)
                            ->where('user_type', 'assessor')
                            ->get();

                            $coachings = \App\Models\BookingSession::with([
                                'coach.reviews', 'coach.profilePicture', 'coach.experiences'
                            ])->where('jobseeker_id', $jobseeker->id)
                            ->where('user_type', 'coach')
                            ->get();
                        @endphp

                        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

                        <script>
                            function toggleVisibility(section) {
                                document.querySelectorAll('.' + section + '-item').forEach((el, index) => {
                                    if (index >= 3) el.classList.toggle('d-none');
                                });

                                const button = document.getElementById('viewMoreBtn_' + section);
                                button.innerText = button.innerText === 'View More' ? 'View Less' : 'View More';
                            }
                        </script>

                        <!-- MENTORSHIP SECTION -->
                        <div class="card">
                            <div class="header"><h2>Jobseeker Mentorship</h2></div>
                            <div class="body">
                                <div class="container-fluid"><div class="row"><div class="col-lg-12">
                                    @forelse ($mentorships as $index => $session)
                                        @php
                                            $mentor = $session->mentor;
                                            $reviews = $mentor?->reviews ?? collect();
                                            $experiences = $mentor?->experiences ?? collect();
                                            $averageRating = $reviews->avg('ratings') ?? 0;
                                            $totalReviews = $reviews->count();
                                            $filledStars = floor($averageRating);
                                            $halfStar = ($averageRating - $filledStars) >= 0.5;
                                            $emptyStars = 5 - $filledStars - ($halfStar ? 1 : 0);
                                            $currentExp = $experiences->firstWhere('end_to', null) ?? $experiences->sortByDesc('end_to')->first();
                                            $designation = $currentExp?->job_role ?? 'No designation available';
                                            $slotMode = $session->slot_mode;
                                            $zoomLink = $session->zoom_join_url;
                                            $image = $mentor?->profilePicture?->document_path ?? asset('images/default-mentor.jpg');
                                        @endphp
                                        <div class="card d-flex flex-row align-items-start p-3 mb-4 shadow-sm mentorship-item {{ $index >= 3 ? 'd-none' : '' }}">
                                            <img src="{{ $image }}" class="img-fluid rounded" style="width: 200px; height: 140px; object-fit: cover;">
                                            <div class="ps-4 d-flex flex-column flex-grow-1">
                                                <h5 class="fw-bold mb-1">{{ $mentor->name }}</h5>
                                                <p class="text-muted mb-1">{{ $designation }}</p>
                                                <div class="d-flex align-items-center mb-2">
                                                    @for ($i = 0; $i < $filledStars; $i++) <i class="fas fa-star text-warning"></i> @endfor
                                                    @if ($halfStar)<i class="fas fa-star-half-alt text-warning"></i>@endif
                                                    @for ($i = 0; $i < $emptyStars; $i++) <i class="far fa-star text-warning"></i> @endfor
                                                    <span class="text-muted ms-2">({{ number_format($averageRating, 1) }}/5 from {{ $totalReviews }} reviews)</span>
                                                </div>
                                                @if ($slotMode === 'online' && $zoomLink)
                                                    <a href="{{ $zoomLink }}" target="_blank" class="btn btn-primary btn-sm">Join Meet</a>
                                                @elseif ($slotMode === 'offline')
                                                    <p class="text-muted small mt-1">Offline session - check location</p>
                                                @else
                                                    <p class="text-danger small mt-1">Link not available</p>
                                                @endif
                                            </div>
                                        </div>
                                    @empty
                                        <div class="alert alert-info">No mentorship sessions found.</div>
                                    @endforelse
                                    @if ($mentorships->count() > 3)
                                        <div class="text-center">
                                            <button class="btn btn-sm btn-primary mt-2" id="viewMoreBtn_mentorship" onclick="toggleVisibility('mentorship')">View More</button>
                                        </div>
                                    @endif
                                </div></div></div>
                            </div>
                        </div>

                        <!-- ASSESSMENT SECTION -->
                        <div class="card mt-4">
                            <div class="header"><h2>Jobseeker Assessments</h2></div>
                            <div class="body">
                                <div class="container-fluid"><div class="row"><div class="col-lg-12">
                                    @forelse ($assessments as $index => $session)
                                        @php
                                            $assessor = $session->assessor;
                                            $reviews = $assessor?->reviews ?? collect();
                                            $experiences = $assessor?->experiences ?? collect();
                                            $averageRating = $reviews->avg('ratings') ?? 0;
                                            $totalReviews = $reviews->count();
                                            $filledStars = floor($averageRating);
                                            $halfStar = ($averageRating - $filledStars) >= 0.5;
                                            $emptyStars = 5 - $filledStars - ($halfStar ? 1 : 0);
                                            $designation = optional($experiences->firstWhere('end_to', null) ?? $experiences->sortByDesc('end_to')->first())->job_role ?? 'No designation available';
                                            $slotMode = $session->slot_mode;
                                            $zoomLink = $session->zoom_join_url;
                                            $image = $assessor?->profilePicture?->document_path ?? asset('images/default-mentor.jpg');
                                        @endphp
                                        <div class="card d-flex flex-row align-items-start p-3 mb-4 shadow-sm assessment-item {{ $index >= 3 ? 'd-none' : '' }}">
                                            <img src="{{ $image }}" class="img-fluid rounded" style="width: 200px; height: 140px; object-fit: cover;">
                                            <div class="ps-4 d-flex flex-column flex-grow-1">
                                                <h5 class="fw-bold mb-1">{{ $assessor->name }}</h5>
                                                <p class="text-muted mb-1">{{ $designation }}</p>
                                                <div class="d-flex align-items-center mb-2">
                                                    @for ($i = 0; $i < $filledStars; $i++) <i class="fas fa-star text-warning"></i> @endfor
                                                    @if ($halfStar)<i class="fas fa-star-half-alt text-warning"></i>@endif
                                                    @for ($i = 0; $i < $emptyStars; $i++) <i class="far fa-star text-warning"></i> @endfor
                                                    <span class="text-muted ms-2">({{ number_format($averageRating, 1) }}/5 from {{ $totalReviews }} reviews)</span>
                                                </div>
                                                @if ($slotMode === 'online' && $zoomLink)
                                                    <a href="{{ $zoomLink }}" target="_blank" class="btn btn-primary btn-sm">Join Meet</a>
                                                @elseif ($slotMode === 'offline')
                                                    <p class="text-muted small mt-1">Offline session - check location</p>
                                                @else
                                                    <p class="text-danger small mt-1">Link not available</p>
                                                @endif
                                            </div>
                                        </div>
                                    @empty
                                        <div class="alert alert-info">No assessment sessions found.</div>
                                    @endforelse
                                    @if ($assessments->count() > 3)
                                        <div class="text-center">
                                            <button class="btn btn-sm btn-primary mt-2" id="viewMoreBtn_assessment" onclick="toggleVisibility('assessment')">View More</button>
                                        </div>
                                    @endif
                                </div></div></div>
                            </div>
                        </div>

                        <!-- COACHING SECTION -->
                        <div class="card mt-4">
                            <div class="header"><h2>Jobseeker Coaching</h2></div>
                            <div class="body">
                                <div class="container-fluid"><div class="row"><div class="col-lg-12">
                                    @forelse ($coachings as $index => $session)
                                        @php
                                            $coach = $session->coach;
                                            $reviews = $coach?->reviews ?? collect();
                                            $experiences = $coach?->experiences ?? collect();
                                            $averageRating = $reviews->avg('ratings') ?? 0;
                                            $totalReviews = $reviews->count();
                                            $filledStars = floor($averageRating);
                                            $halfStar = ($averageRating - $filledStars) >= 0.5;
                                            $emptyStars = 5 - $filledStars - ($halfStar ? 1 : 0);
                                            $designation = optional($experiences->firstWhere('end_to', null) ?? $experiences->sortByDesc('end_to')->first())->job_role ?? 'No designation available';
                                            $slotMode = $session->slot_mode;
                                            $zoomLink = $session->zoom_join_url;
                                            $image = $coach?->profilePicture?->document_path ?? asset('images/default-mentor.jpg');
                                        @endphp
                                        <div class="card d-flex flex-row align-items-start p-3 mb-4 shadow-sm coaching-item {{ $index >= 3 ? 'd-none' : '' }}">
                                            <img src="{{ $image }}" class="img-fluid rounded" style="width: 200px; height: 140px; object-fit: cover;">
                                            <div class="ps-4 d-flex flex-column flex-grow-1">
                                                <h5 class="fw-bold mb-1">{{ $coach->name }}</h5>
                                                <p class="text-muted mb-1">{{ $designation }}</p>
                                                <div class="d-flex align-items-center mb-2">
                                                    @for ($i = 0; $i < $filledStars; $i++) <i class="fas fa-star text-warning"></i> @endfor
                                                    @if ($halfStar)<i class="fas fa-star-half-alt text-warning"></i>@endif
                                                    @for ($i = 0; $i < $emptyStars; $i++) <i class="far fa-star text-warning"></i> @endfor
                                                    <span class="text-muted ms-2">({{ number_format($averageRating, 1) }}/5 from {{ $totalReviews }} reviews)</span>
                                                </div>
                                                @if ($slotMode === 'online' && $zoomLink)
                                                    <a href="{{ $zoomLink }}" target="_blank" class="btn btn-primary btn-sm">Join Meet</a>
                                                @elseif ($slotMode === 'offline')
                                                    <p class="text-muted small mt-1">Offline session - check location</p>
                                                @else
                                                    <p class="text-danger small mt-1">Link not available</p>
                                                @endif
                                            </div>
                                        </div>
                                    @empty
                                        <div class="alert alert-info">No coaching sessions found.</div>
                                    @endforelse
                                    @if ($coachings->count() > 3)
                                        <div class="text-center">
                                            <button class="btn btn-sm btn-primary mt-2" id="viewMoreBtn_coaching" onclick="toggleVisibility('coaching')">View More</button>
                                        </div>
                                    @endif
                                </div></div></div>
                            </div>
                        </div>



                            <div class="card">
                                <div class="header">
                                    <h2>Jobseeker Subscriptions</h2>
                                </div>
                                <div class="body">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-lg-12">

                                                @if(count($subscriptionPlans) > 0)
                                                    @foreach ($subscriptionPlans as $index => $plan)
                                                        <div class="card p-3 mb-4 shadow-sm {{ $index > 0 ? 'd-none extra-subscription' : '' }}">
                                                            <div class="d-flex flex-column">
                                                                <h5 class="fw-bold mb-1">{{ $plan->title }}</h5>
                                                                <p class="text-muted mb-2">{{ $plan->description }}</p>
                                                                <div class="mb-2">
                                                                    <strong>Duration:</strong> {{ $plan->duration_days }} Days<br>
                                                                    <strong>Purchased On:</strong> 
                                                                        {{ \Carbon\Carbon::parse($plan->start_date)->format('d M Y') }}<br>
                                                                    <strong>Expired On:</strong> 
                                                                        {{ \Carbon\Carbon::parse($plan->end_date)->format('d M Y') }}
                                                                </div>
                                                                <span class="badge bg-secondary text-white small align-self-start px-2 py-1">
                                                                    ₹{{ $plan->price }}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    @endforeach

                                                    <!-- View More Button (only show if more than 1 subscription exists) -->
                                                    @if(count($subscriptionPlans) > 1)
                                                        <div class="text-center mt-4">
                                                            <button class="btn btn-primary" id="toggleButtonSub"
                                                                onclick="toggleSubscriptions()">View More</button>
                                                        </div>
                                                    @endif
                                                @else
                                                    <div class="alert alert-info text-center p-3">
                                                        No subscriptions found.
                                                    </div>
                                                    
                                                @endif

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Toggle Script -->
                            <script>
                                function toggleSubscriptions() {
                                    const extraSubs = document.querySelectorAll('.extra-subscription');
                                    const button = document.getElementById("toggleButtonSub");

                                    let hidden = [...extraSubs].some(el => el.classList.contains("d-none"));

                                    extraSubs.forEach(el => el.classList.toggle("d-none", !hidden));
                                    button.textContent = hidden ? "View Less" : "View More";
                                }
                            </script>


                            @php
                                // Fetch payments for this jobseeker
                                $payments = App\Models\PaymentHistory::where('user_type', 'jobseeker')
                                            ->where('user_id', $jobseeker->id)
                                            ->orderBy('created_at', 'desc')
                                            ->get();

                                $statusColors = [
                                    'pending' => 'warning text-dark',
                                    'completed' => 'success text-white',
                                    'failed' => 'danger text-white',
                                    'refunded' => 'info text-dark',
                                ];

                                $visiblePayments = $payments->take(3); // first 3 payments
                                $hiddenPayments = $payments->slice(3); // rest of the payments
                            @endphp

                            <div class="card">
                                <div class="header">
                                    <h2>{{ $jobseeker->name }}'s Payments</h2>
                                </div>
                                <div class="body">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-lg-12">

                                                <!-- Visible Payments -->
                                                @foreach($visiblePayments as $payment)
                                                    <div class="card p-3 mb-4 shadow-sm">
                                                        <div class="d-flex flex-column">
                                                            <h5 class="fw-bold mb-2">Payment #{{ str_pad($payment->id, 3, '0', STR_PAD_LEFT) }}</h5>
                                                            <div class="mb-2">
                                                                <strong>Paid On:</strong> {{ $payment->paid_at ? \Carbon\Carbon::parse($payment->paid_at)->format('d M Y') : 'N/A' }}<br>
                                                                <strong>Amount:</strong> ₹{{ number_format($payment->amount_paid, 2) }}<br>
                                                                <strong>Payment Status:</strong>
                                                                @php
                                                                    $statusClass = $statusColors[$payment->payment_status] ?? 'secondary text-white';
                                                                @endphp
                                                                <span class="badge bg-{{ explode(' ', $statusClass)[0] }} {{ explode(' ', $statusClass)[1] ?? '' }} small px-2 py-1">
                                                                    {{ ucfirst($payment->payment_status) }}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach

                                                <!-- Hidden More Payments -->
                                                @if($hiddenPayments->count() > 0)
                                                    <div id="morePayments" class="d-none">
                                                        @foreach($hiddenPayments as $payment)
                                                            <div class="card p-3 mb-4 shadow-sm">
                                                                <div class="d-flex flex-column">
                                                                    <h5 class="fw-bold mb-2">Payment #{{ str_pad($payment->id, 3, '0', STR_PAD_LEFT) }}</h5>
                                                                    <div class="mb-2">
                                                                        <strong>Paid On:</strong> {{ $payment->paid_at ? \Carbon\Carbon::parse($payment->paid_at)->format('d M Y') : 'N/A' }}<br>
                                                                        <strong>Amount:</strong> ₹{{ number_format($payment->amount_paid, 2) }}<br>
                                                                        <strong>Payment Status:</strong>
                                                                        @php
                                                                            $statusClass = $statusColors[$payment->payment_status] ?? 'secondary text-white';
                                                                        @endphp
                                                                        <span class="badge bg-{{ explode(' ', $statusClass)[0] }} {{ explode(' ', $statusClass)[1] ?? '' }} small px-2 py-1">
                                                                            {{ ucfirst($payment->payment_status) }}
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    </div>

                                                    <!-- View More Button -->
                                                    <div class="text-center mt-4">
                                                        <button class="btn btn-primary" id="toggleButtonPay" onclick="togglePayments()">View More</button>
                                                    </div>
                                                @endif

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- JS Toggle -->
                                <script>
                                    function togglePayments() {
                                        const morePayments = document.getElementById("morePayments");
                                        const button = document.getElementById("toggleButtonPay");

                                        if (morePayments.classList.contains("d-none")) {
                                            morePayments.classList.remove("d-none");
                                            button.textContent = "View Less";
                                        } else {
                                            morePayments.classList.add("d-none");
                                            button.textContent = "View More";
                                        }
                                    }
                                </script>
                            </div>




                            <div class="card">
                                <div class="header">
                                    <h2>Jobseeker Certifications</h2>
                                </div>
                                <div class="body">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-lg-12">

                                                @foreach($certificates as $index => $cert)
                                                    <div class="card p-3 mb-3 shadow-sm">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <div>
                                                                <h6 class="fw-bold mb-1">{{ $cert->course_name }}</h6>
                                                                <p class="text-muted mb-0">
                                                                    <strong>Issued On:</strong> {{ \Carbon\Carbon::parse($cert->completion_date)->format('d F Y') }}
                                                                </p>
                                                            </div>
                                                            <button class="btn btn-sm btn-outline-primary"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#certModal{{ $index }}">
                                                                View
                                                            </button>
                                                        </div>
                                                    </div>

                                                    <!-- Modal for this certificate -->
                                                    <div class="modal fade" id="certModal{{ $index }}" tabindex="-1" aria-labelledby="certModal{{ $index }}Label" aria-hidden="true">
                                                        <div class="modal-dialog modal-xl modal-dialog-centered">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="certModal{{ $index }}Label">{{ $cert->course_name }}</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                                </div>
                                                                <div class="modal-body text-center">
                                                                    <!-- ✅ Certificate show in iframe -->
                                                                    <iframe src="{{ route('admin.viewCertificate', [$jobseeker->id, $cert->material_id]) }}" 
                                                                            frameborder="0" width="100%" height="600px"></iframe>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                                @if($certificates->isEmpty())
                                                    <p class="text-muted">No certificates available.</p>
                                                @endif

                                            </div>
                                        </div>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>

    @include('admin.componants.footer')