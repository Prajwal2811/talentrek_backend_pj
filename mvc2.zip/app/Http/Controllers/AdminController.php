<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Admin;
use App\Models\CMS;
use App\Models\Coach;
use App\Models\Assessors;
use App\Models\RecruiterCompany;
use App\Models\Setting;
use App\Models\SocialMedia;
use App\Models\Jobseekers;
use App\Models\Recruiters;
use App\Models\AdditionalInfo;
use App\Models\Testimonial;
use App\Models\Trainers;
use App\Models\Language;
use App\Models\Resume;
use App\Models\Review;
use App\Models\JobseekerTrainingMaterialPurchase;
use App\Models\PaymentHistory   ;
use App\Models\Mentors;
use App\Models\BookingSession;
use App\Models\RecruiterJobseekersShortlist;
use App\Models\TrainingBatch;
use App\Models\TrainerAssessment;
use App\Models\TrainingMaterialsDocument;
use App\Models\CertificateTemplate;
use App\Models\TrainingMaterial;
use App\Models\TrainingCategory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use App\Models\Subscription;
use App\Models\PurchasedSubscription;
use App\Models\SubscriptionPlan;
use Carbon\Carbon;
use App\Services\ZoomService;

use App\Models\Notification;

use App\Models\Coupon;
use App\Models\Taxation;
use Barryvdh\DomPDF\Facade\Pdf;
use Dompdf\Dompdf;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\View;

use DB;
class AdminController extends Controller
{
    public function authenticate(Request $request)
    {
        $this->validate($request, [
            'email'     => 'required|email',
            'password'  => 'required'
        ]);

        $credentials = [
            'email'    => $request->email,
            'password' => $request->password,
            'status'   => 'active'
        ];

        if (Auth::guard('admin')->attempt($credentials, $request->get('remember'))) {
            $admin = Auth::guard('admin')->user();

            Log::info('Admin login successful', [
                'email' => $admin->email,
                'name'  => $admin->name,
                'role'  => $admin->role, // assuming 'role' is a column like 'admin' or 'superadmin'
                'time'  => now()
            ]);

            return redirect()->route('admin.dashboard');
        } else {
            Log::warning('Admin login failed', [
                'email' => $request->email,
                'time'  => now()
            ]);

            session()->flash('error', 'Either Email/Password is incorrect');
            return back()->withInput($request->only('email'));
        }
    }


    public function sendResetPassword(Request $request)
    {
        // Validate input
        $request->validate([
            'email' => 'required|email|exists:admins,email',
        ]);

        try {
            // Find the admin
            $admin = Admin::where('email', $request->email)->first();

            if ($admin) {
                // Extract username part from email
                $username = strstr($admin->email, '@', true);

                // Create new password
                $newPassword = $username . '@talentrek';

                // Update password
                $admin->password = Hash::make($newPassword);
                $admin->pass = $newPassword;
                $admin->save();

                // Log password reset
                Log::info('Password reset for admin: ' . $admin->email, [
                    'admin_id' => $admin->id,
                    'new_password' => $newPassword, // ⚠️ For production, remove or mask this
                    'timestamp' => now()
                ]);

                // Send email
                Mail::html(
                    '
                        <!DOCTYPE html>
                            <html lang="en">
                            <head>
                                <meta charset="UTF-8">
                                <title>Password Reset</title>
                                <style>
                                    body {
                                        background-color: #f6f8fa;
                                        font-family: Arial, sans-serif;
                                        padding: 20px;
                                        margin: 0;
                                        color: #333;
                                    }
                                    .container {
                                        background-color: #ffffff;
                                        padding: 30px;
                                        max-width: 500px;
                                        margin: 20px auto;
                                        border-radius: 8px;
                                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                                    }
                                    .otp-box {
                                        font-size: 24px;
                                        font-weight: bold;
                                        background-color: #f0f4ff;
                                        padding: 15px;
                                        text-align: center;
                                        border: 1px dashed #007bff;
                                        border-radius: 6px;
                                        margin: 20px 0;
                                        color: #007bff;
                                    }
                                    .footer {
                                        font-size: 12px;
                                        text-align: center;
                                        margin-top: 30px;
                                        color: #888;
                                    }
                                </style>
                            </head>
                            <body>
                                <div class="container">
                                    <h2>Password Reset Successful</h2>
                                    <p>Hello, ' . $admin->name . '!</p>
                                    <p>Your new password has been generated successfully. Use the password below to log in:</p>

                                    <div class="otp-box">' . $newPassword . '</div>

                                    <p>For your security, we recommend changing this password after logging in.</p>

                                    <p>Thanks,<br><strong>The Talentrek Team</strong></p>
                                </div>

                                <div class="footer">
                                    &copy; ' . date('Y') . ' Talentrek. All rights reserved.
                                </div>
                            </body>
                            </html>
                    ',
                    function ($message) use ($admin) {
                        $message->to($admin->email)->subject('Your New Password – Talentrek');
                    }
                );

                return back()->with('success', 'A new password has been sent to your email.');
            }

            Log::warning('Password reset attempted for non-existent admin email: ' . $request->email);
            return back()->with('error', 'Admin not found.');
        } catch (\Exception $e) {
            Log::error('Error during password reset: ' . $e->getMessage(), [
                'email' => $request->email,
                'timestamp' => now()
            ]);
            return back()->with('error', 'An error occurred while resetting the password.');
        }
    }


    public function signOut()
    {
        // Capture admin info before logout
        $admin = Auth::guard('admin')->user();

        if ($admin) {
            Log::info('Admin logged out', [
                'email' => $admin->email,
                'name'  => $admin->name,
                'role'  => $admin->role, // assuming 'role' is a column like 'admin' or 'superadmin'
                'time'  => now()
            ]);
        }

        Auth::guard('admin')->logout(); // Logs out the admin user
        session()->flash('success', 'You have been logged out successfully.');
        
        return redirect()->route('admin.login'); // Redirect to named route
    }

    public function dashboard()
    {
        $jobseekerCount = Jobseekers::where('status', 'active')->count();
        $recruiterCount = Recruiters::where('status', 'active')->count();
        $trainerCount   = Trainers::where('status', 'active')->count();
        // $expatCount     = Expats::where('status', 'active')->count();
        $coachCount     = Coach::where('status', 'active')->count();
        $mentorCount    = Mentors::where('status', 'active')->count();
        $assessorCount  = Assessors::where('status', 'active')->count();

        // Example logic for revenue and session counts
        $materialSales = JobseekerTrainingMaterialPurchase::select('.')
                                        ->join('payments_history', 'jobseeker_training_material_purchases.payment_id', '=', 'payments_history.id')
                                        ->where('payments_history.payment_status', 'paid')
                                        ->sum('payments_history.amount_paid');


        $mentorSessionCount = BookingSession::where('user_type', 'mentor')->count();
        $coachSessionCount = BookingSession::where('user_type', 'coach')->count();
        $assessorSessionCount = BookingSession::where('user_type', 'assessor')->count();


        $roleCounts = [
            'Jobseeker' => Jobseekers::count(),
            'Recruiter' => Recruiters::count(),
            'Trainer' => Trainers::count(),
            // 'Expat' => Expats::count(),
            'Coach' => Coach::count(),
            'Mentor' => Mentors::count(),
            'Assessor' => Assessors::count(),
        ];

        $months = collect(range(1, 12)); // All 12 months

        $currentYear = now()->year;

        $jobseekerData = $months->map(fn($month) =>
            Jobseekers::whereMonth('created_at', $month)->whereYear('created_at', $currentYear)->count()
        );

        $recruiterData = $months->map(fn($month) =>
            Recruiters::whereMonth('created_at', $month)->whereYear('created_at', $currentYear)->count()
        );

        $trainerData = $months->map(fn($month) =>
            Trainers::whereMonth('created_at', $month)->whereYear('created_at', $currentYear)->count()
        );

        return view('admin.dashboard', [
            'jobseekerCount'        => $jobseekerCount,
            'recruiterCount'        => $recruiterCount,
            'trainerCount'          => $trainerCount,
            // 'expatCount'            => $expatCount,
            'coachCount'            => $coachCount,
            'mentorCount'           => $mentorCount,
            'assessorCount'         => $assessorCount,
            'materialSales'         => $materialSales,
            'mentorSessionCount'    => $mentorSessionCount,
            'coachSessionCount'     => $coachSessionCount,
            'assessorSessionCount'  => $assessorSessionCount,
            'roleCounts'            => $roleCounts,
            'jobseekerData' => $jobseekerData,
            'recruiterData' => $recruiterData,
            'trainerData' => $trainerData,
        ]);
    }

    public function create()
    {
        return view('admin.admin.create');
    }

    public function store(Request $request)
    {
        // Validate the form inputs
        $validator = Validator::make($request->all(), [
            'full_name'         => 'required|string|max:255',
            'email'             => 'required|email|unique:admins,email',
            'password'          => 'required|string|min:6',
            'confirm_password'  => 'required|same:password',
            'notes'             => 'nullable|string',
            'permissions' => 'array',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        // Create new Admin
        $admin = new Admin();
        $admin->name = $request->input('full_name');
        $admin->email = $request->input('email');
        $admin->password = Hash::make($request->input('password'));
        $admin->pass = $request->input('password'); // ❗️Don't store raw passwords in production
        $admin->notes = $request->input('notes');
        $admin->role = 'admin';
        $admin->status = 'active';
        $admin->permissions = $request->permissions; // auto-cast to JSON
        $admin->save();

        // Fetch current user details
        $currentUser = auth()->user();

        // Log the creation with detailed info
        Log::info('New admin account created', [
            'action_by_email' => $currentUser?->email ?? 'system',
            'action_by_name' => $currentUser?->name ?? 'System',
            'action_by_role' => $currentUser?->role ?? 'unknown',
            'new_admin_email' => $admin->email,
            'new_admin_name' => $admin->name,
            'time' => now()
        ]);

        return redirect()->route('admin.index')->with('success', 'Admin created successfully!');
    }


    public function index()
    {   
        $admins = Admin::where('role', 'admin')->get();
        return view('admin.admin.index', compact('admins'));
    }


    public function destroy($id)
    {
        // Find the admin by ID
        $admin = Admin::findOrFail($id);

        // Capture info before deleting
        $deletedAdminInfo = [
            'id' => $admin->id,
            'name' => $admin->name,
            'email' => $admin->email,
            'role' => $admin->role,
        ];

        // Delete the admin
        $admin->delete();

        // Logged-in user info
        $actor = auth()->user();

        // Log the deletion
        Log::warning('Admin account deleted', [
            'deleted_admin' => $deletedAdminInfo,
            'deleted_by_name' => $actor?->name ?? 'System',
            'deleted_by_email' => $actor?->email ?? 'system',
            'deleted_by_role' => $actor?->role ?? 'unknown',
            'time' => now()
        ]);

        // Redirect back with a success message
        return redirect()->route('admin.index')->with('success', 'Admin deleted successfully.');
    }


    public function changeStatus(Request $request)
    {
        $validated = $request->validate([
            'admin_id' => 'required|exists:admins,id',
            'status' => 'required|in:active,inactive',
        ]);

        $user = Admin::findOrFail($validated['admin_id']);
        $previousStatus = $user->status;
        $user->status = $validated['status'];
        $user->save();

        // Get the actor (admin or superadmin who performed the action)
        $actor = auth()->user();

        // Log the status change
        Log::info('Admin status changed', [
            'target_admin' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'previous_status' => $previousStatus,
                'new_status' => $user->status
            ],
            'changed_by' => [
                'id' => $actor?->id ?? null,
                'name' => $actor?->name ?? 'System',
                'email' => $actor?->email ?? 'system',
                'role' => $actor?->role ?? 'unknown'
            ],
            'time' => now()
        ]);

        return response()->json([
            'message' => 'Admin status updated successfully.',
            'status' => $user->status
        ]);
    }


    public function assignAdmin(Request $request)
    {
        // Validate incoming data
        $validated = $request->validate([
            'admin_id' => 'required|exists:admins,id',
            'jobseeker_ids' => 'required|string',
            'user_type' => 'required|in:jobseeker,expat',
        ]);

        $adminId = $validated['admin_id'];
        $userIds = explode(',', $validated['jobseeker_ids']);
        $userType = $validated['user_type']; // 'jobseeker' or 'expat'
        $assignedCount = 0;
        $assignedUsers = [];

        foreach ($userIds as $id) {
            $user = Jobseekers::find($id);

            if ($user) {
                $user->assigned_admin = $adminId;
                $user->save();

                $assignedCount++;
                $assignedUsers[] = [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email ?? null,
                ];
            }
        }

        $assignedAdmin = Admin::find($adminId);
        $actor = auth()->user();

        Log::info(ucfirst($userType) . 's assigned to admin', [
            'assigned_to_admin' => [
                'id' => $assignedAdmin->id,
                'name' => $assignedAdmin->name,
                'email' => $assignedAdmin->email,
                'role' => $assignedAdmin->role,
            ],
            'assigned_by' => [
                'id' => $actor?->id ?? null,
                'name' => $actor?->name ?? 'System',
                'email' => $actor?->email ?? 'system',
                'role' => $actor?->role ?? 'unknown',
            ],
            'users_assigned' => $assignedUsers,
            'total_assigned' => $assignedCount,
            'time' => now()
        ]);

        $message = $assignedCount > 0
            ? ucfirst($userType) . 's have been successfully assigned to the admin.'
            : 'No ' . $userType . 's were assigned.';

        return redirect()->back()->with('success', $message);
    }


    


    public function unassign(Request $request)
    {
        $jobseeker = Jobseekers::find($request->id);

        if ($jobseeker) {
            $previousAdminId = $jobseeker->assigned_admin;

            // Fetch previous admin info (if exists)
            $previousAdmin = $previousAdminId ? Admin::find($previousAdminId) : null;

            // Perform unassignment
            $jobseeker->assigned_admin = null;
            $jobseeker->save();

            // Get actor info
            $actor = auth()->user();

            // Log the unassignment
            Log::info('Jobseeker unassigned from admin', [
                'jobseeker' => [
                    'id' => $jobseeker->id,
                    'name' => $jobseeker->name,
                    'email' => $jobseeker->email ?? null,
                ],
                'previous_admin' => $previousAdmin ? [
                    'id' => $previousAdmin->id,
                    'name' => $previousAdmin->name,
                    'email' => $previousAdmin->email,
                    'role' => $previousAdmin->role
                ] : 'None',
                'unassigned_by' => [
                    'id' => $actor?->id ?? null,
                    'name' => $actor?->name ?? 'System',
                    'email' => $actor?->email ?? 'system',
                    'role' => $actor?->role ?? 'unknown'
                ],
                'time' => now()
            ]);

            return response()->json(['success' => true]);
        }

        return response()->json(['success' => false]);
    }

    public function edit($id)
    {
        $admin = Admin::findOrFail($id);
        return view('admin.admin.edit', compact('admin'));
    }


    public function update(Request $request, $id)
    {
        $request->validate([
            'full_name' => 'required|string|max:255',
            'email' => 'required|email|unique:admins,email,' . $id,
            'notes' => 'nullable|string',
            'permissions' => 'nullable|array', // ✅ validate permissions array
        ]);

        $admin = Admin::findOrFail($id);

        // Save old data for logging
        $oldData = $admin->only(['name', 'email', 'notes', 'permissions']);

        // Update admin
        $admin->name = $request->input('full_name');
        $admin->email = $request->input('email');
        $admin->notes = $request->input('notes');
        $admin->permissions = $request->input('permissions', []); // ✅ save permissions
        $admin->save();

        // Log activity
        $actor = auth()->user();
        Log::info('Admin profile updated', [
            'target_admin' => [
                'id' => $admin->id,
                'old_data' => $oldData,
                'new_data' => $admin->only(['name', 'email', 'notes', 'permissions']),
            ],
            'updated_by' => [
                'id' => $actor?->id,
                'name' => $actor?->name,
                'email' => $actor?->email,
                'role' => $actor?->role,
            ],
            'time' => now(),
        ]);

        return redirect()->route('admin.index')->with('success', 'Admin updated successfully.');
    }


    public function jobseekers()
    {   
        $admin = Auth::guard('admin')->user();
        $adminId = $admin->id;
        // If the user is a superadmin, show all jobseekers
        if ($admin->role === 'superadmin') {
            $jobseekers = Jobseekers::orderBy('id', 'desc')->where('role','jobseeker')
                                    ->get();
        } else {
            // Else show only jobseekers assigned to this admin
            $jobseekers = Jobseekers::where('assigned_admin', $adminId)
                                    ->orderBy('id', 'desc')->where('role','jobseeker')
                                    ->get();
        }

        $admins = Admin::where('role', 'admin')->get();

        return view('admin.jobseeker.index', compact('jobseekers', 'admins'));
    }



    public function jobseekerChangeStatus(Request $request)
    {
        $validated = $request->validate([
            'jobseeker_id' => 'required|exists:jobseekers,id',
            'status' => 'required|in:active,inactive',
            'reason' => 'nullable|string|max:1000'
        ]);

        $user = Jobseekers::findOrFail($validated['jobseeker_id']);
        $oldStatus = $user->status;
        $oldReason = $user->inactive_reason;

        $user->status = $validated['status'];

        if ($validated['status'] === 'inactive' && isset($validated['reason'])) {
            $user->inactive_reason = $validated['reason'];
        } else {
            $user->inactive_reason = null;
        }

        $user->save();

        // Actor performing the change
        $actor = auth()->user();

        // Logging the change
        Log::info('Jobseeker status updated', [
            'jobseeker' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email ?? null,
                'old_status' => $oldStatus,
                'new_status' => $user->status,
                'old_reason' => $oldReason,
                'new_reason' => $user->inactive_reason
            ],
            'changed_by' => [
                'id' => $actor?->id ?? null,
                'name' => $actor?->name ?? 'System',
                'email' => $actor?->email ?? 'system',
                'role' => $actor?->role ?? 'unknown'
            ],
            'time' => now()
        ]);

        if($user->status == 'active'){
            $status = 'Approved';
        }else{
            $status = 'Rejected';
        }
        $data = [
            'sender_id' => $validated['jobseeker_id'],
            'sender_type' => 'Jobseeker '.$status,
            'receiver_id' => '1',
            'message' => $user->name.' Jobseeker '.$status,
            'is_read' => 0,
            'is_read_admin' => 0,
            'user_type' => 'jobseeker'
        ];

        Notification::insert($data);

        return response()->json([
            'message' => 'Jobseeker status updated successfully.',
            'status' => $user->status
        ]);
    }


    public function jobseekerView($id)
    {
        $jobseeker = Jobseekers::findOrFail($id);
        $educations = $jobseeker->educations()->orderBy('id', 'desc')->get();
        $experiences = $jobseeker->experiences()->orderBy('id', 'desc')->get();
        $skills = $jobseeker->skills()->orderBy('id', 'desc')->get();
        $additioninfos = AdditionalInfo::select('*')->where('user_id' , $id)->where('user_type','jobseeker')->get();
        $subscriptionPlans = PurchasedSubscription::select('subscription_plans.*','purchased_subscriptions.*')
                                                    ->where('purchased_subscriptions.user_id', $id)
                                                    ->where('purchased_subscriptions.user_type', 'jobseeker')
                                                    ->join('subscription_plans', 'purchased_subscriptions.subscription_plan_id', '=', 'subscription_plans.id')
                                                    ->get();
        $certificates = DB::table('jobseeker_assessment_status as jas')
            ->join('training_materials as t', 'jas.material_id', '=', 't.id')
            ->leftJoin('trainers as tr', 't.trainer_id', '=', 'tr.id')
            ->select(
                't.training_title as course_name',
                'jas.created_at as completion_date',
                'jas.material_id' // ✅ yeh add karo
            )
            ->where('jas.jobseeker_id', $id)
            ->where('jas.submitted', 1)
            ->get();

        // echo "<pre>";                                         
        // print_r($certificates); die;    
        return view('admin.jobseeker.view', compact('jobseeker', 'experiences', 'educations', 'skills','additioninfos','subscriptionPlans', 'certificates'));
    }


    public function updateStatus(Request $request)
    {
        $request->validate([
            'jobseeker_id' => 'required|exists:jobseekers,id',
            'status' => 'required|in:approved,rejected,superadmin_approved,superadmin_rejected',
            'reason' => 'nullable|string|max:1000',
        ]);

        $jobseeker = Jobseekers::findOrFail($request->jobseeker_id);
        $user = auth()->user();
        $previousStatus = $jobseeker->admin_status;
        $status = $request->status;

        // Role validation
        if ($user->role === 'superadmin' && !Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Invalid status for superadmin');
        } elseif ($user->role === 'admin' && Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Admins cannot perform superadmin actions');
        } elseif (!in_array($user->role, ['admin', 'superadmin'])) {
            Log::warning('Unauthorized jobseeker status update attempt', [
                'attempted_by' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                ],
                'jobseeker_id' => $jobseeker->id,
                'time' => now(),
            ]);
            return back()->with('error', 'Unauthorized action.');
        }

        // Update status and rejection reason
        $jobseeker->admin_status = $status;
        $jobseeker->rejection_reason = Str::endsWith($status, 'rejected') ? $request->reason : null;
        $jobseeker->save();

        // Log the update
        Log::info('Jobseeker admin status updated', [
            'jobseeker' => [
                'id' => $jobseeker->id,
                'name' => $jobseeker->name,
                'email' => $jobseeker->email,
                'previous_status' => $previousStatus,
                'new_status' => $status,
                'rejection_reason' => $jobseeker->rejection_reason,
            ],
            'updated_by' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
            ],
            'time' => now(),
        ]);

        // Send email if rejected
        if (Str::endsWith($status, 'rejected') && $request->filled('reason') && $jobseeker->email) {
            Mail::html('
                <!DOCTYPE html>
                <html>
                <head><meta charset="UTF-8"><title>Application Rejected – Talentrek</title>
                <style>
                    body { font-family: Arial, sans-serif; background-color: #f6f8fa; padding: 20px; color: #333; }
                    .container { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }
                    .header { text-align: center; margin-bottom: 20px; }
                    .footer { font-size: 12px; text-align: center; color: #999; margin-top: 30px; }
                    .reason { background-color: #ffe6e6; border-left: 4px solid #dc3545; padding: 10px 15px; margin: 15px 0; }
                </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h2>Application Update – <span style="color:#dc3545;">Rejected</span></h2>
                        </div>
                        <p>Hi <strong>' . e($jobseeker->name ?? $jobseeker->email) . '</strong>,</p>
                        <p>We regret to inform you that your application on <strong>Talentrek</strong> has been rejected.</p>
                        <div class="reason"><strong>Reason:</strong> ' . e($request->reason) . '</div>
                        <p>If you believe this was a mistake, contact <a href="mailto:support@talentrek.com">support@talentrek.com</a>.</p>
                        <p>Thank you,<br><strong>The Talentrek Team</strong></p>
                    </div>
                    <div class="footer">© ' . date('Y') . ' Talentrek. All rights reserved.</div>
                </body>
                </html>
            ', function ($message) use ($jobseeker) {
                $message->to($jobseeker->email)->subject('Application Rejected – Talentrek');
            });
        }

        return back()->with('success', 'Status updated successfully.');
    }





    public function recruiters()
    {
        $recruiters = Recruiters::with('company')
                                ->orderBy('recruiters.id', 'desc')
                                ->get();
        return view('admin.recruiter.index', compact('recruiters'));
    }


    public function recruiterChangeStatus(Request $request)
    {
        $validated = $request->validate([
            'company_id' => 'required|exists:recruiters_company,id',
            'status' => 'required|in:active,inactive',
            'reason' => 'nullable|string|max:1000'
        ]);

        $user = RecruiterCompany::findOrFail($validated['company_id']);
        $oldStatus = $user->status;
        $oldReason = $user->inactive_reason;

        $user->status = $validated['status'];

        if ($validated['status'] === 'inactive' && isset($validated['reason'])) {
            $user->inactive_reason = $validated['reason'];
        } else {
            $user->inactive_reason = null;
        }

        $user->save();

        // Actor performing the change
        $actor = auth()->user();
        // Logging the change
        Log::info('Recruiter status updated', [
            'recruiter' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email ?? null,
                'old_status' => $oldStatus,
                'new_status' => $user->status,
                'old_reason' => $oldReason,
                'new_reason' => $user->inactive_reason
            ],
            'changed_by' => [
                'id' => $actor?->id ?? null,
                'name' => $actor?->name ?? 'System',
                'email' => $actor?->email ?? 'system',
                'role' => $actor?->role ?? 'unknown'
            ],
            'time' => now()
        ]);

        if($user->status == 'active'){
            $status = 'Approved';
        }else{
            $status = 'Rejected';
        }
        $data = [
            'sender_id' => $validated['company_id'],
            'sender_type' => 'Recruiter '.$status,
            'receiver_id' => '1',
            'message' => $user->name.' Recruiter '.$status,
            'is_read' => 0,
            'is_read_admin' => 0,
            'user_type' => 'recruiter'
        ];

        Notification::insert($data);

        return response()->json([
            'message' => 'Recruiter status updated successfully.',
            'status' => $user->status
        ]);
    }

    public function recruiterView($id)
    {
        $recruiter = Recruiters::findOrFail($id);
        $company   = $recruiter->company;

        // ✅ Additional Info of recruiter
        $additioninfos = AdditionalInfo::where('user_id', $id)
                                    ->where('user_type', 'recruiter')
                                    ->get();

        // ✅ Fetch subscriptions purchased by company (not recruiter)
        $subscriptionPlans = [];
        if ($company) {
            $subscriptionPlans = PurchasedSubscription::select(
                            'subscription_plans.*',
                            'purchased_subscriptions.*',
                            'recruiters_company.active_subscription_plan_id'
                        )
                        ->where('purchased_subscriptions.company_id', $company->id)
                        ->where('purchased_subscriptions.user_type', 'recruiter')
                        ->join('subscription_plans', 'purchased_subscriptions.subscription_plan_id', '=', 'subscription_plans.id')
                        ->join('recruiters_company', 'recruiters_company.id', '=', 'purchased_subscriptions.company_id')
                        ->get();

        }

        return view('admin.recruiter.view', compact('recruiter', 'company', 'additioninfos', 'subscriptionPlans'));
    }



    public function viewShortlistedJobseekers($id)
    {
        // echo "<pre>"; print_r($id); die;
        $shortlistJobseekers = RecruiterJobseekersShortlist::select('recruiter_jobseeker_shortlist.*','jobseekers.*','recruiter_jobseeker_shortlist.admin_status as admin_status_rjs')->where('recruiter_id', $id)
                                                            ->join('jobseekers', 'recruiter_jobseeker_shortlist.jobseeker_id', '=', 'jobseekers.id')
                                                            ->get();
        // echo "<pre>";  print_r($shortlistJobseekers); die ;    
        return view('admin.recruiter.shortlisted-jobseekers', compact('shortlistJobseekers'));
    }

    public function updateStatusForShortlist(Request $request)
    {
        $rules = [
            'jobseeker_id' => 'required|exists:jobseekers,id',
            'status'       => 'required|in:approved,rejected',
            'role'         => 'required|in:admin,superadmin',
        ];

        // Extra validation rules
        if ($request->status === 'rejected') {
            $rules['reason'] = 'required|string|max:500';
        }
        if ($request->status === 'approved' && $request->role === 'superadmin') {
            $rules['interview_date']   = 'required|date';
            $rules['interview_time']   = 'required';
        }

        $validated = $request->validate($rules);

        $jobseeker = RecruiterJobseekersShortlist::where('jobseeker_id', $request->jobseeker_id)->firstOrFail();
 
        $jobseekerDetails = Jobseekers::where('id', $request->jobseeker_id)->firstOrFail();
        if ($request->role === 'admin') {
            $jobseeker->admin_status = $request->status;
            $jobseeker->rejection_reason = $request->status === 'rejected' ? $request->reason : null;
        } elseif ($request->role === 'superadmin') {
            if ($jobseeker->admin_status === 'approved') {
                $jobseeker->admin_status = 'superadmin_' . $request->status;
                $jobseeker->interview_status = 'scheduled';
                $jobseeker->rejection_reason = $request->status === 'rejected' ? $request->reason : null;

                if ($request->status === 'approved') {
                    // Save interview schedule
                    $jobseeker->interview_date = $request->interview_date;
                    $jobseeker->interview_time = $request->interview_time;
                    // ✅ If online mode, create Zoom meeting
                    try {
                        $zoom = new ZoomService();
                        $startTime = $request->interview_date . ' ' . $request->interview_time;

                        $zoomMeeting = $zoom->createMeeting("Interview with #{$jobseeker->id}", $startTime);

                        if ($zoomMeeting) {
                            $jobseeker->zoom_start_url = $zoomMeeting['start_url'];
                            $jobseeker->zoom_join_url  = $zoomMeeting['join_url'];
                        } else {
                            Log::error('Zoom creation failed for interview', [
                                'jobseeker_id' => $jobseeker->id,
                                'interview_date' => $request->interview_date,
                                'interview_time' => $request->interview_time,
                            ]);
                            return back()->with('error', 'Zoom meeting creation failed. Please try again later.');
                        }
                        $data = [
                            'sender_id' => $request->jobseeker_id,
                            'sender_type' => 'You are shortlisted for interview.',
                            'receiver_id' => '1',
                            'message' => 'You are shortlisted for interview on '.$request->interview_date.' at'.$request->interview_time.'.',
                            'is_read_users' => 0,
                            'user_type' => 'jobseeker'
                        ];

                        Notification::insert($data);

                        $data1 = [
                            'sender_id' => $jobseeker->recruiter_id,
                            'sender_type' => 'Superadmin scheduled interview for jobseeker.',
                            'receiver_id' => '1',
                            'message' => 'Superadmin scheduled interview for '.$jobseekerDetails->name.' on '.$request->interview_date.' at'.$request->interview_time.'.',
                            'is_read_users' => 0,
                            'user_type' => 'recruiter'
                        ];

                        Notification::insert($data1);
                    } catch (\Exception $e) {
                        Log::error('Zoom API Exception', [
                            'message' => $e->getMessage(),
                            'jobseeker_id' => $jobseeker->id,
                        ]);
                        return back()->with('error', 'Zoom meeting creation failed. Please try again.');
                    }
                }
            }
        }

        $jobseeker->save();

        return back()->with('success', 'Status updated successfully.');
    }





    public function updateRecruiterStatus(Request $request)

{

    $request->validate([

        'recruiter_id' => 'required|exists:recruiters,id',

        'status' => 'required|in:approved,rejected,superadmin_approved,superadmin_rejected',

        'reason' => 'nullable|string|max:1000',

    ]);



    $recruiter = Recruiters::findOrFail($request->recruiter_id);

    $user = auth()->user();

    $previousStatus = $recruiter->admin_status;

    $status = $request->status;



    // Role validation

    if ($user->role === 'superadmin') {

        if (!Str::startsWith($status, 'superadmin_')) {

            return response()->json(['success' => false, 'message' => 'Invalid status for superadmin'], 403);

        }



        if ($recruiter->admin_status === 'rejected') {

            return response()->json(['success' => false, 'message' => 'Cannot override admin rejection'], 403);

        }



    } elseif ($user->role === 'admin') {

        if (Str::startsWith($status, 'superadmin_')) {

            return response()->json(['success' => false, 'message' => 'Admins cannot perform superadmin actions'], 403);

        }



    } else {

        Log::warning('Unauthorized recruiter status update attempt', [

            'attempted_by' => $user->only(['id', 'name', 'email', 'role']),

            'recruiter_id' => $recruiter->id,

            'time' => now(),

        ]);

        return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);

    }



    // Save status

    $recruiter->admin_status = $status;

    $recruiter->rejection_reason = Str::endsWith($status, 'rejected') ? $request->reason : null;

    $recruiter->save();



    Log::info('Recruiter status updated', [

        'recruiter' => $recruiter->only(['id', 'name', 'email']),

        'previous_status' => $previousStatus,

        'new_status' => $status,

        'rejection_reason' => $recruiter->rejection_reason,

        'updated_by' => $user->only(['id', 'name', 'email', 'role']),

        'time' => now(),

    ]);





    // Email on rejection

    if (Str::endsWith($status, 'rejected') && $request->filled('reason') && $recruiter->email) {

        Mail::html('

                <!DOCTYPE html>

                <html>

                <head><meta charset="UTF-8"><title>Recruiter Application Rejected</title>

                <style>

                    body { font-family: Arial, sans-serif; background-color: #f6f8fa; padding: 20px; color: #333; }

                    .container { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }

                    .header { text-align: center; margin-bottom: 20px; }

                    .footer { font-size: 12px; text-align: center; color: #999; margin-top: 30px; }

                    .reason { background-color: #ffe6e6; border-left: 4px solid #dc3545; padding: 10px 15px; margin: 15px 0; }

                </style>

                </head>

                <body>

                    <div class="container">

                        <div class="header">

                            <h2>Recruiter Application – <span style="color:#dc3545;">Rejected</span></h2>

                        </div>

                        <p>Hi <strong>' . e($recruiter->name ?? $recruiter->email) . '</strong>,</p>

                        <p>Your recruiter registration has been rejected on <strong>Talentrek</strong>.</p>

                        <div class="reason"><strong>Reason:</strong> ' . e($request->reason) . '</div>

                        <p>If you have questions, contact <a href="mailto:support@talentrek.com">support@talentrek.com</a>.</p>

                        <p>Thank you,<br><strong>The Talentrek Team</strong></p>

                    </div>

                    <div class="footer">© ' . date('Y') . ' Talentrek. All rights reserved.</div>

                </body>

                </html>

            ', function ($message) use ($recruiter) {

                $message->to($recruiter->email)->subject('Recruiter Application Rejected – Talentrek');

            });

    }



    return response()->json(['success' => true, 'message' => 'Status updated successfully.']);

}

    public function cms()
    {
        $cmsmodules = CMS::get();
        return view('admin.cms.index', compact('cmsmodules'));
    }

    public function cmsEdit($slug)
    {
        $cms = CMS::where('slug', $slug)->first();
        return view('admin.cms.edit', compact('cms'));
    }

    public function updateBanner(Request $request)
    {
        // Validate inputs
        $request->validate([
            'slug'         => 'required|string|exists:cms_module,slug',
            'heading'      => 'string|max:255',
            'ar_heading'      => 'string|max:255',
            'description'  => 'string',
            'ar_description'  => 'string',
            'banner_image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
        ]);

        try {
            // Fetch existing CMS banner by slug
            $cms = CMS::where('slug', $request->slug)->firstOrFail();

            // Handle new file upload and delete old file
            if ($request->hasFile('banner_image')) {
                $fileName = $request->file('banner_image')->getClientOriginalName();
                $extension = $request->file('banner_image')->getClientOriginalExtension();
                $fileNameToStore  = 'banner_image_' . date('Ymdhis') . '.' . $extension;
                $path = asset('uploads/' . $fileNameToStore);
                $request->file('banner_image')->move('uploads/', $fileNameToStore);
                // $decryptedId = $request->input('id');
                CMS::where('slug', $cms->slug)->update(['file_path' => $path, 'file_name' => $fileName]);
            }

            // Update text fields
            $cms->heading     = $request->heading;
            $cms->ar_heading     = $request->ar_heading;
            $cms->description = $request->description;
            $cms->ar_description = $request->ar_description;

            // Save record
            $cms->save();

           return redirect()->back()->with('success', $cms->slug === 'banner' ? 'Banner updated successfully!' : 'Section data updated successfully!');


        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Update failed: ' . $e->getMessage());
        }
    } 



    public function settings()
    {
        return view('admin.settings.index');
    }


    public function settingsUpdate(Request $request)
    {
        $request->validate([
            'header_logo'  => 'nullable|image|mimes:jpeg,png,jpg,webp,svg|max:2048',
            'footer_logo'  => 'nullable|image|mimes:jpeg,png,jpg,webp,svg|max:2048',
            'favicon_icon' => 'nullable|image|mimes:jpeg,png,jpg,ico,webp,svg|max:1024',
        ]);

        $setting = Setting::find($request->input('id')) ?? new Setting();

        // Upload folder
        $uploadPath = public_path('uploads');

        // Handle header logo
        if ($request->hasFile('header_logo')) {
            if (!empty($setting->header_logo) && file_exists(public_path($setting->header_logo))) {
                unlink(public_path($setting->header_logo));
            }
            $headerLogo = $request->file('header_logo');
            $headerLogoName = 'header_logo_' . time() . '.' . $headerLogo->getClientOriginalExtension();
            $headerLogo->move($uploadPath, $headerLogoName);
            $setting->header_logo = 'uploads/' . $headerLogoName;
        }

        // Handle footer logo
        if ($request->hasFile('footer_logo')) {
            if (!empty($setting->footer_logo) && file_exists(public_path($setting->footer_logo))) {
                unlink(public_path($setting->footer_logo));
            }
            $footerLogo = $request->file('footer_logo');
            $footerLogoName = 'footer_logo_' . time() . '.' . $footerLogo->getClientOriginalExtension();
            $footerLogo->move($uploadPath, $footerLogoName);
            $setting->footer_logo = 'uploads/' . $footerLogoName;
        }

        // Handle favicon
        if ($request->hasFile('favicon_icon')) {
            if (!empty($setting->favicon) && file_exists(public_path($setting->favicon))) {
                unlink(public_path($setting->favicon));
            }
            $favicon = $request->file('favicon_icon');
            $faviconName = 'favicon_' . time() . '.' . $favicon->getClientOriginalExtension();
            $favicon->move($uploadPath, $faviconName);
            $setting->favicon = 'uploads/' . $faviconName;
        }

        $setting->save();

        return redirect()->back()->with('success', 'Site settings updated successfully.');
    }


    public function resume()
    {
        $resume = Resume::latest()->first();
        return view('admin.resume.index', compact('resume'));
    }


    // public function resumeUpdate(Request $request)
    // {
    //     $request->validate([
    //         'resume' => 'required',
    //     ]);

    //     $resume = Resume::find($request->input('id')) ?? new Resume();
    //     $resume->resume = $request->input('resume');
    //     $resume->save();

    //     return redirect()->route('admin.resume.download.option', ['id' => $resume->id])
    //                     ->with('success', 'Resume format uploaded successfully.');
    // }

   

    public function resumeUpdate(Request $request)
    {
        $request->validate([
            'resume' => 'required',
            'resume_file' => 'required|file|mimes:pdf,doc,docx|max:5120',
        ]);

        $resume = Resume::find($request->input('id')) ?? new Resume();
        $resume->resume = $request->input('resume');

        if ($request->hasFile('resume_file')) {
            $file = $request->file('resume_file');
            $fileName = time() . '_' . $file->getClientOriginalName();

            $destinationPath = public_path('assets/resumes');

            if (!File::exists($destinationPath)) {
                File::makeDirectory($destinationPath, 0777, true, true);
            }

            $file->move($destinationPath, $fileName);

            $resume->resume_file = $fileName;
            $resume->resume_file_path = 'assets/resumes/' . $fileName;
        }

        $resume->save();

        return redirect()
            ->route('admin.resume')
            ->with('success', 'Resume format uploaded successfully.');
    }





    public function storeMediaLinks(Request $request)
    {
        $request->validate([
            'media_name.*' => 'required|string|max:100',
            'icon_class.*' => 'nullable|string|max:100',
            'media_link.*' => 'required|url|max:255',
        ]);

        // Optional: Clear existing links before saving new ones
        SocialMedia::truncate();

        // Save all entries
        foreach ($request->media_name as $index => $name) {
            SocialMedia::create([
                'media_name' => $name,
                'icon_class' => $request->icon_class[$index] ?? null,
                'media_link' => $request->media_link[$index],
            ]);
        }

        return back()->with('success', 'Social media links saved successfully.');
    }


    public function testimonials(){
        $testimonials = Testimonial::all();
        return view('admin.testimonials.index', compact('testimonials'));
    }

    public function createTestimonial(){
        return view('admin.testimonials.create');
    }



    public function storeTestimonial(Request $request)
    {
        // Validate the incoming request data
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'designation' => 'required|string|max:255',
            'message' => 'required|string',
            'profile_picture' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        $testimonial = new Testimonial();
        $testimonial->name = $validated['name'];
        $testimonial->designation = $validated['designation'];
        $testimonial->message = $validated['message'];

        // Handle image upload if present
        if ($request->hasFile('profile_picture')) {
                $fileName = $request->file('profile_picture')->getClientOriginalName();
                $filePath = 'profile_picture_' . time() . '.' . $request->file('profile_picture')->getClientOriginalExtension();
                $request->file('profile_picture')->move('uploads/', $filePath);
                $testimonial->file_name = $fileName;
                $testimonial->file_path = asset('uploads/' . $filePath);
        }

        $testimonial->save();

        return redirect()->route('admin.testimonials')->with('success', 'Testimonial added successfully!');
    }

    public function editTestimonial($id)
    {
        $testimonial = Testimonial::findOrFail($id);
        return view('admin.testimonials.edit', compact('testimonial'));
    }


    public function updateTestimonial(Request $request, $id)
    {
        // Validate the request
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'designation' => 'required|string|max:255',
            'message' => 'required|string',
            'profile_picture' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        // Find testimonial
        $testimonial = Testimonial::findOrFail($id);
        $testimonial->name = $validated['name'];
        $testimonial->designation = $validated['designation'];
        $testimonial->message = $validated['message'];

        // Handle image upload if present
        if ($request->hasFile('profile_picture')) {
            $image = $request->file('profile_picture');

            // Get original name for reference
            $originalName = $image->getClientOriginalName();

            // Generate unique filename
            $uniqueName = 'profile_picture_' . time() . '.' . $image->getClientOriginalExtension();

            // Move file to public/uploads/
            $image->move(public_path('uploads'), $uniqueName);

            // Store in database
            $testimonial->file_name = $originalName;
            $testimonial->file_path = asset('uploads/' . $uniqueName); // relative path for use with asset()
        }


        $testimonial->save();

        return redirect()->route('admin.testimonials')->with('success', 'Testimonial updated successfully!');
    }

    public function destroyTestimonial($id)
    {
        $testimonial = Testimonial::findOrFail($id);
        $testimonial->delete();
        return redirect()->route('admin.testimonials')->with('success', 'Testimonial deleted successfully!');
    }


    public function trainers()
    {
        $trainers = Trainers::all();
        return view('admin.trainers.index', compact('trainers'));
    }


    public function trainerChangeStatus(Request $request)
    { 
        $validated = $request->validate([
            'trainer_id' => 'required|exists:trainers,id',
            'status' => 'required|in:active,inactive',
            'reason' => 'nullable|string|max:1000'
        ]);

        $user = Trainers::findOrFail($validated['trainer_id']);
        $oldStatus = $user->status;
        $oldReason = $user->inactive_reason;

        $user->status = $validated['status'];

        if ($validated['status'] === 'inactive' && isset($validated['reason'])) {
            $user->inactive_reason = $validated['reason'];
        } else {
            $user->inactive_reason = null;
        }

        $user->save();

        // Actor performing the change
        $actor = auth()->user();
        // Logging the change
        Log::info('Trainer status updated', [
            'trainer' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email ?? null,
                'old_status' => $oldStatus,
                'new_status' => $user->status,
                'old_reason' => $oldReason,
                'new_reason' => $user->inactive_reason
            ],
            'changed_by' => [
                'id' => $actor?->id ?? null,
                'name' => $actor?->name ?? 'System',
                'email' => $actor?->email ?? 'system',
                'role' => $actor?->role ?? 'unknown'
            ],
            'time' => now()
        ]);

        if($user->status == 'active'){
            $status = 'Approved';
        }else{
            $status = 'Rejected';
        }
        $data = [
            'sender_id' => $validated['trainer_id'],
            'sender_type' => 'Trainer '.$status,
            'receiver_id' => '1',
            'message' => $user->name.' Trainer '.$status,
            'is_read' => 0,
            'is_read_admin' => 0,
            'user_type' => 'trainer'
        ];

        Notification::insert($data);

        return response()->json([
            'message' => 'Trainer status updated successfully.',
            'status' => $user->status
        ]);
    }

    public function viewTrainer($id)
    {
        $trainer = Trainers::findOrFail($id);
        $educations = $trainer->educations()->orderBy('id', 'desc')->get();
        $workExperiences  = $trainer->experiences()->orderBy('id', 'desc')->get();
        $trainingExperiences  = $trainer->experience()->orderBy('id', 'desc')->get();
        $additioninfos = AdditionalInfo::select('*')->where('user_id' , $id)->where('user_type','trainer')->get();
        $subscriptionPlans = PurchasedSubscription::select('subscription_plans.*','purchased_subscriptions.*')
                                                    ->where('purchased_subscriptions.user_id', $id)
                                                    ->where('purchased_subscriptions.user_type', 'trainer')
                                                    ->join('subscription_plans', 'purchased_subscriptions.subscription_plan_id', '=', 'subscription_plans.id')
                                                    ->get();
        return view('admin.trainers.view', compact('trainer', 'educations', 'workExperiences', 'trainingExperiences','additioninfos','subscriptionPlans'));
    }


    public function viewTrainingMaterial($id)
    {
        $materials = TrainingMaterial::select('training_materials_documents.*','training_materials.*','training_materials.id as material_id')
                                    ->where('training_materials.trainer_id',$id)
                                    ->leftJoin('training_materials_documents', 'training_materials_documents.training_material_id','training_materials.id')        
                                    ->get();
        
        return view('admin.trainers.material.training-material', compact('materials'));
    }

    public function viewTrainingMaterialDetail($trainerId, $materialId)
    {
        $course = TrainingMaterial::select('*')->where('trainer_id', $trainerId)
                                    ->where('id', $materialId)
                                    ->firstOrFail();

        $batches = TrainingBatch::select('*')->where('trainer_id', $trainerId)->get();

        $courseDocuments = TrainingMaterialsDocument::select('*')->where('trainer_id', $trainerId)->where('training_material_id', $materialId)->get();
        
        $trainer = Trainers::find($trainerId);
        // echo "<pre>"; print_r($trainer); die;
        // echo "<pre>"; print_r($courseDocuments); die;
        return view('admin.trainers.material.training-material-detail', compact('course', 'batches','courseDocuments','trainer'));
    }


  public function trainingMaterialChangeStatus(Request $request)
    {
        $request->validate([
            'course_id' => 'required|exists:training_materials,id',
            'status' => 'required|in:approved,rejected,superadmin_approved,superadmin_rejected',
            'reason' => 'nullable|string|max:1000',
        ]);

        $course = TrainingMaterial::findOrFail($request->course_id);
        $user = auth()->user();
        $status = $request->status;

        // Prevent further changes if superadmin decision is already made
        if (Str::startsWith($course->admin_status, 'superadmin_')) {
            return response()->json(['message' => 'Final decision already made.'], 422);
        }

        // Superadmin can act only after admin approval
        if ($user->role === 'superadmin') {
            if (!Str::startsWith($status, 'superadmin_') || $course->admin_status !== 'approved') {
                
                return response()->json(['message' => 'Superadmin can only act after admin approval.'], 422);
            }
            $data = [
                'sender_id' => $user->id,
                'sender_type' => 'Training material approved by Superadmin',
                'receiver_id' => '1',
                'message' => $user->name.' Training material approved by Superadmin.',
                'is_read_users' => 0,
                'user_type' => 'jobseeker'
            ];

            Notification::insert($data);
        }

        // Admin cannot perform superadmin actions
        if ($user->role === 'admin' && Str::startsWith($status, 'superadmin_')) {
            return response()->json(['message' => 'Admin cannot perform superadmin actions.'], 422);
        }

        // Update status and reason
        $course->admin_status = $status;
        $course->rejection_reason = Str::endsWith($status, 'rejected') ? $request->reason : null;
        $course->save();

        // Send rejection email (HTML) if applicable
        if (Str::endsWith($status, 'rejected') && $request->filled('reason')) {
            $trainer = $course->trainer ?? Trainers::find($course->trainer_id);

            if ($trainer && $trainer->email) {
                $trainerName = $trainer->name ?? $trainer->email;
                $reason = $request->reason;
                $year = date('Y');

                $html = "
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <meta charset='UTF-8'>
                        <title>Application Rejected – Talentrek</title>
                        <style>
                            body {
                                font-family: Arial, sans-serif;
                                background-color: #f6f8fa;
                                padding: 20px;
                                color: #333;
                            }
                            .container {
                                background: #fff;
                                padding: 30px;
                                border-radius: 8px;
                                max-width: 600px;
                                margin: auto;
                                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                            }
                            .header {
                                text-align: center;
                                margin-bottom: 20px;
                            }
                            .reason {
                                background-color: #ffe6e6;
                                border-left: 4px solid #dc3545;
                                padding: 10px 15px;
                                margin: 20px 0;
                            }
                            .footer {
                                font-size: 12px;
                                color: #999;
                                text-align: center;
                                margin-top: 30px;
                            }
                        </style>
                    </head>
                    <body>
                        <div class='container'>
                            <div class='header'>
                                <h2>Application <span style='color: #dc3545;'>Rejected</span></h2>
                            </div>

                            <p>Hello <strong>{$trainerName}</strong>,</p>

                            <p>We regret to inform you that your application on <strong>Talentrek</strong> has been rejected.</p>

                            <div class='reason'>
                                <strong>Reason:</strong><br>
                                {$reason}
                            </div>

                            <p>If you believe this was a mistake, feel free to contact us at <a href='mailto:support@talentrek.com'>support@talentrek.com</a>.</p>

                            <p>Best regards,<br><strong>Talentrek Team</strong></p>

                            <div class='footer'>
                                © {$year} Talentrek. All rights reserved.
                            </div>
                        </div>
                    </body>
                    </html>
                ";

                Mail::html($html, function ($message) use ($trainer) {
                    $message->to($trainer->email)
                            ->subject('Application Rejected – Talentrek');
                });
            }

        }

        return response()->json(['message' => 'Status updated.']);
    }



    public function updateStatusTrainer(Request $request)
    {
        $request->validate([
            'trainer_id' => 'required|exists:trainers,id',
            'status' => 'required|in:approved,rejected,superadmin_approved,superadmin_rejected',
            'reason' => 'nullable|string|max:1000',
        ]);

        $trainer = Trainers::findOrFail($request->trainer_id);
        $user = auth()->user();
        $previousStatus = $trainer->admin_status;
        $status = $request->status;

        // Role validation
        if ($user->role === 'superadmin' && !Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Invalid status for superadmin');
        } elseif ($user->role === 'admin' && Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Admins cannot perform superadmin actions');
        } elseif (!in_array($user->role, ['admin', 'superadmin'])) {
            Log::warning('Unauthorized trainer status update attempt', [
                'attempted_by' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                ],
                'trainer_id' => $trainer->id,
                'time' => now(),
            ]);
            return back()->with('error', 'Unauthorized action.');
        }

        // Update status and rejection reason
        $trainer->admin_status = $status;
        $trainer->rejection_reason = Str::endsWith($status, 'rejected') ? $request->reason : null;
        $trainer->save();

        // Log the update
        Log::info('Rrainer admin status updated', [
            'trainer' => [
                'id' => $trainer->id,
                'name' => $trainer->name,
                'email' => $trainer->email,
                'previous_status' => $previousStatus,
                'new_status' => $status,
                'rejection_reason' => $trainer->rejection_reason,
            ],
            'updated_by' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
            ],
            'time' => now(),
        ]);

        // Send email if rejected
        if (Str::endsWith($status, 'rejected') && $request->filled('reason') && $trainer->email) {
            Mail::html('
                <!DOCTYPE html>
                <html>
                <head><meta charset="UTF-8"><title>Application Rejected – Talentrek</title>
                <style>
                    body { font-family: Arial, sans-serif; background-color: #f6f8fa; padding: 20px; color: #333; }
                    .container { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }
                    .header { text-align: center; margin-bottom: 20px; }
                    .footer { font-size: 12px; text-align: center; color: #999; margin-top: 30px; }
                    .reason { background-color: #ffe6e6; border-left: 4px solid #dc3545; padding: 10px 15px; margin: 15px 0; }
                </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h2>Application Update – <span style="color:#dc3545;">Rejected</span></h2>
                        </div>
                        <p>Hi <strong>' . e($trainer->name ?? $trainer->email) . '</strong>,</p>
                        <p>We regret to inform you that your application on <strong>Talentrek</strong> has been rejected.</p>
                        <div class="reason"><strong>Reason:</strong> ' . e($request->reason) . '</div>
                        <p>If you believe this was a mistake, contact <a href="mailto:support@talentrek.com">support@talentrek.com</a>.</p>
                        <p>Thank you,<br><strong>The Talentrek Team</strong></p>
                    </div>
                    <div class="footer">© ' . date('Y') . ' Talentrek. All rights reserved.</div>
                </body>
                </html>
            ', function ($message) use ($trainer) {
                $message->to($trainer->email)->subject('Application Rejected – Talentrek');
            });
        }

        return back()->with('success', 'Status updated successfully.');
    }


    public function viewTrainerAssessment($id)
    {
        $assessments = TrainerAssessment::select('trainer_assessments.*','training_materials.*')
                                        ->where('trainer_assessments.trainer_id' , $id)
                                        ->join('training_materials','training_materials.id','=','trainer_assessments.material_id')
                                        ->get();
        // echo "<pre>"; print_r($assessments); die;
        return view('admin.trainers.assessment.training-assessment', compact('assessments'));
    }

    
    public function viewTrainingAssessmentDetail($trainerId, $assessmentId)
    {
        // echo "<pre>"; print_r($trainerId); die;

        $assessment = TrainerAssessment::where('trainer_id', $trainerId)
                            ->where('id', $assessmentId)
                            ->with(['questions.options', 'course']) // Load questions with their options and course
                            ->firstOrFail();
        // echo "<pre>"; print_r($assessment); die;
        return view('admin.trainers.assessment.training-assessment-detail', compact('assessment'));

    }

    public function certificationTemplate() {
        return view('admin.certificate.index');
    }


    public function updateTemplate(Request $request)
    {

        // Validate the incoming request
        $request->validate([
            'description' => 'required|string',
        ]);

        // Assuming the certificate ID is passed as hidden input or route parameter
        $certificateId = $request->input('id'); // or retrieve from route if using route-model binding
        $certificate = CertificateTemplate::findOrFail($certificateId);

        // Update the HTML content
        $certificate->template_html = $request->input('description');
        $certificate->save();

        return redirect()->back()->with('success', 'Certificate template updated successfully.');
    }


    public function languages() {
        $language = Language::all();
        return view('admin.languages.index', compact('language'));
    }

    public function updateLanguage(Request $request)
    {
        $language = Language::findOrFail($request->id);
        $language->english = $request->english;
        $language->arabic = $request->arabic;
        $language->save();

        return response()->json([
            'success' => true,
            'message' => 'Language updated successfully.'
        ]);
    }



    public function contactSupport()
    {
        return view('admin.contact-support');
    }


    public function reviews()
    {
        $reviews = Review::select('reviews.*', 'jobseekers.name as reviewer_name','reviews.id as review_id')
                    ->join('jobseekers', 'reviews.jobseeker_id', '=', 'jobseekers.id')
                    ->whereIn('reviews.user_type', ['trainer', 'mentor', 'coach', 'assessor'])
                    ->get();

        // echo "<pre>"; print_r($reviews); die;
        return view('admin.reviews.index', compact('reviews'));
    }


    public function viewReview($id)
    {
        $review = Review::select('reviews.*', 'jobseekers.name as reviewer_name', 'jobseekers.email as reviewer_email')
            ->join('jobseekers', 'reviews.jobseeker_id', '=', 'jobseekers.id')
            ->whereIn('reviews.user_type', ['trainer', 'mentor', 'coach', 'assessor'])
            ->where('reviews.id', $id)
            ->first();

        // Initialize variables
        $revieweeName = null;
        $materialTitle = null;

        switch ($review->user_type) {
            case 'trainer':
                $reviewee = DB::table('trainers')->where('id', $review->user_id)->first();
                $revieweeName = $reviewee->name ?? 'N/A';

                // Also fetch the trainer's material
                $material = DB::table('training_materials')->where('trainer_id', $review->user_id)->first();
                $materialTitle = $material->training_title ?? 'Material not found';
                break;

            case 'mentor':
                $reviewee = DB::table('mentors')->where('id', $review->user_id)->first();
                $revieweeName = $reviewee->name ?? 'N/A';
                break;

            case 'coach':
                $reviewee = DB::table('coaches')->where('id', $review->user_id)->first();
                $revieweeName = $reviewee->name ?? 'N/A';
                break;

            case 'assessor':
                $reviewee = DB::table('assessors')->where('id', $review->user_id)->first();
                $revieweeName = $reviewee->name ?? 'N/A';
                break;
        }

        return view('admin.reviews.view', compact('review', 'revieweeName', 'materialTitle'));
    }



    public function trainingCategory()
    {
        $trainingCategory = TrainingCategory::orderBy('id', 'desc')->get();
        // echo "<pre>"; print_r($reviews); die;
        return view('admin.trainingcategory.index', compact('trainingCategory'));
    }


    public function trainingCategoryEdit($id)
    {
        $trainingCategory = TrainingCategory::find($id);
        // echo "<pre>"; print_r($trainingCategory); die;
        return view('admin.trainingcategory.edit', compact('trainingCategory'));
    }

    public function updatetrainingCategory(Request $request, $id)
    {
        $request->validate([
            'category_name' => 'required|string|max:255',
            'category_icon' => 'nullable|image|mimes:jpg,jpeg,png,svg,gif|max:2048',
        ]);

        $category = TrainingCategory::findOrFail($id);
        $category->category = $request->category_name;

        if ($request->hasFile('category_icon')) {
            $file = $request->file('category_icon');
            $extension = $file->getClientOriginalExtension();
            $fileNameToStore = 'category_icon_' . time() . '.' . $extension;
            $file->move(public_path('uploads'), $fileNameToStore);
            $category->image_path = asset('uploads/' . $fileNameToStore);
            $category->image_name =  $fileNameToStore;
        }

        $category->save();

        return redirect()->route('admin.training-category')->with('success', 'Category updated successfully.');
    }


    public function createCategory()
    {
        return view('admin.trainingcategory.create');
    }


    public function storeCategory(Request $request)
    {
        $request->validate([
            'category_name' => 'required|string|max:255',
            'category_icon' => 'nullable|image|mimes:jpg,jpeg,png,svg,gif|max:2048',
        ]);

        $iconPath = null;

        if ($request->hasFile('category_icon')) {
            $file = $request->file('category_icon');
            $extension = $file->getClientOriginalExtension();
            $fileNameToStore = 'category_icon_' . time() . '.' . $extension;
            $file->move(public_path('uploads'), $fileNameToStore);

            // Store relative path or filename
            $iconPath = asset('uploads/' . $fileNameToStore);
        }

        TrainingCategory::create([
            'category' => $request->category_name,
            'image_path' => $iconPath, // make sure 'icon' column exists in the table
            'image_name' => $fileNameToStore, // make sure 'icon' column exists in the table
        ]);

        return redirect()->route('admin.training-category')->with('success', 'Category added successfully.');
    }



    public function trainingCategoryDestroy($id)
    {
        // Find the category by ID
        $category = TrainingCategory::findOrFail($id);
        // Delete the category
        $category->delete();
        // Redirect back with a success message
        return redirect()->route('admin.training-category')->with('success', 'Category deleted successfully.');
    }



    public function subscriptions()
    {
        return view('admin.subscriptions.index');
    }


    public function showSubscriptions($type)
    {
        $plans = SubscriptionPlan::where('user_type', $type)->get();

        return view('admin.subscriptions.view', [
            'type' => $type,
            'plans' => $plans
        ]);
    }


    public function subscriptionsStore(Request $request)
    {
        $request->validate([
            'user_type' => 'required|in:jobseeker,recruiter,mentor,coach,assessor,expat,trainer',
            'plans' => 'required|array|min:1',
            'plans.*.title' => 'required|string|max:255',
            'plans.*.price' => 'required|numeric|min:0.01',
            'plans.*.duration_months' => 'required|integer|in:1,3,6,12',
            'plans.*.features' => 'nullable|string',
            'plans.*.description' => 'nullable|string',
        ]);

        // Remove existing plans
        SubscriptionPlan::where('user_type', $request->user_type)->delete();

        // Insert new plans
        foreach ($request->plans as $plan) {
            $durationMonths = $plan['duration_months'];

            // calculate duration_days
            if ($durationMonths == 12) {
                $durationDays = 365;
            } else {
                $durationDays = $durationMonths * 30;
            }

            SubscriptionPlan::create([
                'user_type'     => $request->user_type,
                'title'         => $plan['title'],
                'price'         => $plan['price'],
                'duration_months' => $durationMonths,
                'duration_days' => $durationDays,
                'features'      => $plan['features'] ?? null,
                'description'   => $plan['description'] ?? null,
                'is_active'     => true,
            ]);
        }


        return redirect()->back()->with('success', 'Subscription plans updated successfully!');
    }


    public function payments()
    {
        $payments = PaymentHistory::orderBy('created_at', 'desc')->get();

        // Loop through payments to get user and receiver names
        $payments->transform(function ($payment) {

            // Resolve payer name/email based on user_type
            switch ($payment->user_type) {
                case 'jobseeker':
                    $user = Jobseekers::find($payment->user_id);
                    $payment->user_name = $user ? $user->name : null;
                    $payment->user_email = $user ? $user->email : null;
                    break;
                case 'trainer':
                    $user = Trainers::find($payment->user_id);
                    $payment->user_name = $user ? $user->name : null;
                    $payment->user_email = $user ? $user->email : null;
                    break;
                case 'mentor':
                    $user = Mentors::find($payment->user_id);
                    $payment->user_name = $user ? $user->name : null;
                    $payment->user_email = $user ? $user->email : null;
                    break;
                case 'coach':
                    $user = Coach::find($payment->user_id);
                    $payment->user_name = $user ? $user->name : null;
                    $payment->user_email = $user ? $user->email : null;
                    break;
                case 'assessor':
                    $user = Assessors::find($payment->user_id);
                    $payment->user_name = $user ? $user->name : null;
                    $payment->user_email = $user ? $user->email : null;
                    break;
                case 'recruiter':
                    $user = Recruiters::find($payment->user_id);
                    $payment->user_name = $user ? $user->name : null;
                    $payment->user_email = $user ? $user->email : null;
                    break;
                // case 'expat':
                //     $user = Expat::find($payment->user_id);
                //     $payment->user_name = $user ? $user->name : null;
                //     $payment->user_email = $user ? $user->email : null;
                //     break;
                default:
                    $payment->user_name = null;
                    $payment->user_email = null;
            }

            // Resolve receiver name
            if ($payment->receiver_type && $payment->receiver_type !== 'talentrek') {
                $receiverModel = match($payment->receiver_type) {
                    'trainer' => Trainers::class,
                    'mentor' => Mentors::class,
                    'coach' => Coach::class,
                    'assessor' => Assessors::class,
                    'recruiter' => Recruiters::class,
                    // 'expat' => Expat::class,
                    default => null,
                };

                if ($receiverModel) {
                    $receiver = $receiverModel::find($payment->receiver_id);
                    $payment->receiver_name = $receiver ? $receiver->name : null;
                }
            } else {
                $payment->receiver_name = 'Talentrek';
            }

            return $payment;
        });

        return view('admin.payments.index', compact('payments'));
    }


    public function viewPayment($id)
    {
        $payment = PaymentHistory::findOrFail($id);

        // Resolve payer (who paid)
        $payment->user_name = null;
        $payment->user_email = null;

        switch ($payment->user_type) {
            case 'jobseeker':
                $user = Jobseekers::find($payment->user_id);
                break;
            case 'trainer':
                $user = Trainers::find($payment->user_id);
                break;
            case 'mentor':
                $user = Mentors::find($payment->user_id);
                break;
            case 'coach':
                $user = Coach::find($payment->user_id);
                break;
            case 'assessor':
                $user = Assessors::find($payment->user_id);
                break;
            case 'recruiter':
                $user = Recruiters::find($payment->user_id);
                break;
            // case 'expat':
            //     $user = Expat::find($payment->user_id);
            //     break;
            default:
                $user = null;
        }

        if ($user) {
            $payment->user_name = $user->name;
            $payment->user_email = $user->email ?? null;
        }

        // Resolve receiver
        if ($payment->receiver_type && $payment->receiver_type !== 'talentrek') {
            $receiverModel = match($payment->receiver_type) {
                'trainer' => Trainers::class,
                'mentor' => Mentors::class,
                'coach' => Coach::class,
                'assessor' => Assessors::class,
                'recruiter' => Recruiters::class,
                // 'expat' => Expat::class,
                default => null,
            };

            if ($receiverModel) {
                $receiver = $receiverModel::find($payment->receiver_id);
                $payment->receiver_name = $receiver ? $receiver->name : null;
            }
        } else {
            $payment->receiver_name = 'Talentrek';
        }

        // If payment is for training, attach training material info
        $payment->material = null;
        if ($payment->payment_for === 'training' && $payment->material_id) {
            $payment->material = TrainingMaterial::find($payment->material_id);
        }

        return view('admin.payments.view', compact('payment'));
    }




    public function mentors()
    {
        $mentors = Mentors::all();
        return view('admin.mentors.index', compact('mentors'));
    }

    public function mentorChangeStatus(Request $request)
    {
        $validated = $request->validate([
            'mentor_id' => 'required|exists:mentors,id',
            'status' => 'required|in:active,inactive',
            'reason' => 'nullable|string|max:1000'
        ]);

        $user = Mentors::findOrFail($validated['mentor_id']);
        $oldStatus = $user->status;
        $oldReason = $user->inactive_reason;

        $user->status = $validated['status'];

        if ($validated['status'] === 'inactive' && isset($validated['reason'])) {
            $user->inactive_reason = $validated['reason'];
        } else {
            $user->inactive_reason = null;
        }

        $user->save();

        // Actor performing the change
        $actor = auth()->user();
        // Logging the change
        Log::info('Mentors status updated', [
            'mentors' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email ?? null,
                'old_status' => $oldStatus,
                'new_status' => $user->status,
                'old_reason' => $oldReason,
                'new_reason' => $user->inactive_reason
            ],
            'changed_by' => [
                'id' => $actor?->id ?? null,
                'name' => $actor?->name ?? 'System',
                'email' => $actor?->email ?? 'system',
                'role' => $actor?->role ?? 'unknown'
            ],
            'time' => now()
        ]);

        if($user->status == 'active'){
            $status = 'Approved';
        }else{
            $status = 'Rejected';
        }
        $data = [
            'sender_id' => $validated['mentor_id'],
            'sender_type' => 'Mentor '.$status,
            'receiver_id' => '1',
            'message' => $user->name.' Mentor '. $status,
            'is_read' => 0,
            'is_read_admin' => 0,
            'user_type' => 'mentor'
        ];

        Notification::insert($data);

        return response()->json([
            'message' => 'Mentors status updated successfully.',
            'status' => $user->status
        ]);
    }


    public function viewMentor($id)
    {
        $mentor = Mentors::findOrFail($id);
        $educations = $mentor->educations()->orderBy('id', 'desc')->get();
        $experiences = $mentor->experiences()->orderBy('id', 'desc')->get();
        $trainingexperience = $mentor->trainingexperience()->orderBy('id', 'desc')->get();
        $additioninfos = AdditionalInfo::select('*')->where('user_id' , $id)->where('user_type','mentor')->get();
        $subscriptionPlans = PurchasedSubscription::select('subscription_plans.*','purchased_subscriptions.*')
                                                    ->where('purchased_subscriptions.user_id', $id)
                                                    ->where('purchased_subscriptions.user_type', 'mentor')
                                                    ->join('subscription_plans', 'purchased_subscriptions.subscription_plan_id', '=', 'subscription_plans.id')
                                                    ->get();
        return view('admin.mentors.view', compact('mentor', 'educations', 'experiences', 'trainingexperience','additioninfos','subscriptionPlans'));
    }


    public function updateMentorStatus(Request $request)
    {
        $request->validate([
            'mentor_id' => 'required|exists:mentors,id',
            'status' => 'required|in:approved,rejected,superadmin_approved,superadmin_rejected',
            'reason' => 'nullable|string|max:1000',
        ]);

        $mentor = Mentors::findOrFail($request->mentor_id);
        $user = auth()->user();
        $previousStatus = $mentor->admin_status;
        $status = $request->status;

        // Role validation
        if ($user->role === 'superadmin' && !Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Invalid status for superadmin');
        } elseif ($user->role === 'admin' && Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Admins cannot perform superadmin actions');
        } elseif (!in_array($user->role, ['admin', 'superadmin'])) {
            Log::warning('Unauthorized mentor status update attempt', [
                'attempted_by' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                ],
                'mentor_id' => $mentor->id,
                'time' => now(),
            ]);
            return back()->with('error', 'Unauthorized action.');
        }

        // Update status and rejection reason
        $mentor->admin_status = $status;
        $mentor->rejection_reason = Str::endsWith($status, 'rejected') ? $request->reason : null;
        $mentor->save();

        // Log the update
        Log::info('mentor admin status updated', [
            'mentor' => [
                'id' => $mentor->id,
                'name' => $mentor->name,
                'email' => $mentor->email,
                'previous_status' => $previousStatus,
                'new_status' => $status,
                'rejection_reason' => $mentor->rejection_reason,
            ],
            'updated_by' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
            ],
            'time' => now(),
        ]);

        // Send email if rejected
        if (Str::endsWith($status, 'rejected') && $request->filled('reason') && $mentor->email) {
            Mail::html('
                <!DOCTYPE html>
                <html>
                <head><meta charset="UTF-8"><title>Application Rejected – Talentrek</title>
                <style>
                    body { font-family: Arial, sans-serif; background-color: #f6f8fa; padding: 20px; color: #333; }
                    .container { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }
                    .header { text-align: center; margin-bottom: 20px; }
                    .footer { font-size: 12px; text-align: center; color: #999; margin-top: 30px; }
                    .reason { background-color: #ffe6e6; border-left: 4px solid #dc3545; padding: 10px 15px; margin: 15px 0; }
                </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h2>Application Update – <span style="color:#dc3545;">Rejected</span></h2>
                        </div>
                        <p>Hi <strong>' . e($mentor->name ?? $mentor->email) . '</strong>,</p>
                        <p>We regret to inform you that your application on <strong>Talentrek</strong> has been rejected.</p>
                        <div class="reason"><strong>Reason:</strong> ' . e($request->reason) . '</div>
                        <p>If you believe this was a mistake, contact <a href="mailto:support@talentrek.com">support@talentrek.com</a>.</p>
                        <p>Thank you,<br><strong>The Talentrek Team</strong></p>
                    </div>
                    <div class="footer">© ' . date('Y') . ' Talentrek. All rights reserved.</div>
                </body>
                </html>
            ', function ($message) use ($mentor) {
                $message->to($mentor->email)->subject('Application Rejected – Talentrek');
            });
        }

        return back()->with('success', 'Status updated successfully.');
    }



    public function viewBookingSession($id)
    {
        $bookingSessions = BookingSession::select('jobseeker_saved_booking_session.*', 'mentors.name as mentor_name', 'mentors.email as mentor_email','jobseekers.name as jobseeker_name', 'jobseekers.email as jobseeker_email','booking_slots.start_time', 'booking_slots.end_time','booking_slots.*','jobseeker_saved_booking_session.status as booking_status','jobseeker_saved_booking_session.id as booking_id')
                                ->join('mentors', 'jobseeker_saved_booking_session.user_id', '=', 'mentors.id')
                                ->join('jobseekers', 'jobseeker_saved_booking_session.jobseeker_id', '=', 'jobseekers.id')
                                ->join('booking_slots', 'jobseeker_saved_booking_session.booking_slot_id', '=', 'booking_slots.id')
                                ->where('jobseeker_saved_booking_session.user_id', $id)
                                ->where('jobseeker_saved_booking_session.user_type', 'mentor')
                                ->get();


        // $bookingSessions = BookingSession::select('jobseeker_saved_booking_session.*')
        //                                         ->where('jobseeker_saved_booking_session.user_id', $id)
        //                                         ->where('jobseeker_saved_booking_session.user_type', 'mentor')
        //                                         ->get();
        // echo "<pre>"; print_r($bookingSessions); die;
        return view('admin.mentors.booking-session', compact('bookingSessions'));
    }



    public function coach()
    {
        $coaches = Coach::all();
        return view('admin.coach.index', compact('coaches'));
    }

    public function coachChangeStatus(Request $request)
    {
        $validated = $request->validate([
            'coach_id' => 'required|exists:coaches,id',
            'status' => 'required|in:active,inactive',
            'reason' => 'nullable|string|max:1000'
        ]);

        $user = Coach::findOrFail($validated['coach_id']);
        $oldStatus = $user->status;
        $oldReason = $user->inactive_reason;

        $user->status = $validated['status'];

        if ($validated['status'] === 'inactive' && isset($validated['reason'])) {
            $user->inactive_reason = $validated['reason'];
        } else {
            $user->inactive_reason = null;
        }

        $user->save();

        // Actor performing the change
        $actor = auth()->user();
        // Logging the change
        Log::info('Coach status updated', [
            'coach' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email ?? null,
                'old_status' => $oldStatus,
                'new_status' => $user->status,
                'old_reason' => $oldReason,
                'new_reason' => $user->inactive_reason
            ],
            'changed_by' => [
                'id' => $actor?->id ?? null,
                'name' => $actor?->name ?? 'System',
                'email' => $actor?->email ?? 'system',
                'role' => $actor?->role ?? 'unknown'
            ],
            'time' => now()
        ]);

        if($user->status == 'active'){
            $status = 'Approved';
        }else{
            $status = 'Rejected';
        }
        $data = [
            'sender_id' => $validated['coach_id'],
            'sender_type' => 'Coach '.$status,
            'receiver_id' => '1',
            'message' => $user->name.' Coach '. $status,
            'is_read' => 0,
            'is_read_admin' => 0,
            'user_type' => 'coach'
        ];

        Notification::insert($data);

        return response()->json([
            'message' => 'Coach status updated successfully.',
            'status' => $user->status
        ]);
    }

    public function viewCoach($id)
    {
        $coach = Coach::findOrFail($id);
        $educations = $coach->educations()->orderBy('id', 'desc')->get();
        $experiences = $coach->experiences()->orderBy('id', 'desc')->get();
        $trainingexperience = $coach->trainingexperience()->orderBy('id', 'desc')->get();
        $additioninfos = AdditionalInfo::select('*')->where('user_id' , $id)->where('user_type','coach')->get();
        $subscriptionPlans = PurchasedSubscription::select('subscription_plans.*','purchased_subscriptions.*')
                                                    ->where('purchased_subscriptions.user_id', $id)
                                                    ->where('purchased_subscriptions.user_type', 'coach')
                                                    ->join('subscription_plans', 'purchased_subscriptions.subscription_plan_id', '=', 'subscription_plans.id')
                                                    ->get();
        return view('admin.coach.view', compact('coach', 'educations', 'experiences', 'trainingexperience','additioninfos','subscriptionPlans'));
    }


    public function updateCoachStatus(Request $request)
    {
        $request->validate([
            'coach_id' => 'required|exists:coaches,id',
            'status' => 'required|in:approved,rejected,superadmin_approved,superadmin_rejected',
            'reason' => 'nullable|string|max:1000',
        ]);

        $coach = Coach::findOrFail($request->coach_id);
        $user = auth()->user();
        $previousStatus = $coach->admin_status;
        $status = $request->status;

        // Role validation
        if ($user->role === 'superadmin' && !Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Invalid status for superadmin');
        } elseif ($user->role === 'admin' && Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Admins cannot perform superadmin actions');
        } elseif (!in_array($user->role, ['admin', 'superadmin'])) {
            Log::warning('Unauthorized mentor status update attempt', [
                'attempted_by' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                ],
                'coach_id' => $coach->id,
                'time' => now(),
            ]);
            return back()->with('error', 'Unauthorized action.');
        }

        // Update status and rejection reason
        $coach->admin_status = $status;
        $coach->rejection_reason = Str::endsWith($status, 'rejected') ? $request->reason : null;
        $coach->save();

        // Log the update
        Log::info('Coach admin status updated', [
            'coach' => [
                'id' => $coach->id,
                'name' => $coach->name,
                'email' => $coach->email,
                'previous_status' => $previousStatus,
                'new_status' => $status,
                'rejection_reason' => $coach->rejection_reason,
            ],
            'updated_by' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
            ],
            'time' => now(),
        ]);

        // Send email if rejected
        if (Str::endsWith($status, 'rejected') && $request->filled('reason') && $coach->email) {
            Mail::html('
                <!DOCTYPE html>
                <html>
                <head><meta charset="UTF-8"><title>Application Rejected – Talentrek</title>
                <style>
                    body { font-family: Arial, sans-serif; background-color: #f6f8fa; padding: 20px; color: #333; }
                    .container { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }
                    .header { text-align: center; margin-bottom: 20px; }
                    .footer { font-size: 12px; text-align: center; color: #999; margin-top: 30px; }
                    .reason { background-color: #ffe6e6; border-left: 4px solid #dc3545; padding: 10px 15px; margin: 15px 0; }
                </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h2>Application Update – <span style="color:#dc3545;">Rejected</span></h2>
                        </div>
                        <p>Hi <strong>' . e($coach->name ?? $coach->email) . '</strong>,</p>
                        <p>We regret to inform you that your application on <strong>Talentrek</strong> has been rejected.</p>
                        <div class="reason"><strong>Reason:</strong> ' . e($request->reason) . '</div>
                        <p>If you believe this was a mistake, contact <a href="mailto:support@talentrek.com">support@talentrek.com</a>.</p>
                        <p>Thank you,<br><strong>The Talentrek Team</strong></p>
                    </div>
                    <div class="footer">© ' . date('Y') . ' Talentrek. All rights reserved.</div>
                </body>
                </html>
            ', function ($message) use ($coach) {
                $message->to($coach->email)->subject('Application Rejected – Talentrek');
            });
        }

        return back()->with('success', 'Status updated successfully.');
    }




    public function viewCoachBookingSession($id)
    {
        $bookingSessions = BookingSession::select('jobseeker_saved_booking_session.*', 'coaches.name as coach_name', 'coaches.email as coach_email','jobseekers.name as jobseeker_name', 'jobseekers.email as jobseeker_email','booking_slots.start_time', 'booking_slots.end_time','booking_slots.*','jobseeker_saved_booking_session.status as booking_status','jobseeker_saved_booking_session.id as booking_id')
                                ->join('coaches', 'jobseeker_saved_booking_session.user_id', '=', 'coaches.id')
                                ->join('jobseekers', 'jobseeker_saved_booking_session.jobseeker_id', '=', 'jobseekers.id')
                                ->join('booking_slots', 'jobseeker_saved_booking_session.booking_slot_id', '=', 'booking_slots.id')
                                ->where('jobseeker_saved_booking_session.user_id', $id)
                                ->where('jobseeker_saved_booking_session.user_type', 'coach')
                                ->get();
        return view('admin.coach.booking-session', compact('bookingSessions'));
    }






    public function assessors()
    {
        $assessors = Assessors::all();
        return view('admin.assessors.index', compact('assessors'));
    }

    public function assessorChangeStatus(Request $request)
    {
        $validated = $request->validate([
            'assessor_id' => 'required|exists:assessors,id',
            'status' => 'required|in:active,inactive',
            'reason' => 'nullable|string|max:1000'
        ]);

        $user = Assessors::findOrFail($validated['assessor_id']);
        $oldStatus = $user->status;
        $oldReason = $user->inactive_reason;

        $user->status = $validated['status'];

        if ($validated['status'] === 'inactive' && isset($validated['reason'])) {
            $user->inactive_reason = $validated['reason'];
        } else {
            $user->inactive_reason = null;
        }

        $user->save();

        // Actor performing the change
        $actor = auth()->user();
        // Logging the change
        Log::info('Assessor status updated', [
            'assessor' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email ?? null,
                'old_status' => $oldStatus,
                'new_status' => $user->status,
                'old_reason' => $oldReason,
                'new_reason' => $user->inactive_reason
            ],
            'changed_by' => [
                'id' => $actor?->id ?? null,
                'name' => $actor?->name ?? 'System',
                'email' => $actor?->email ?? 'system',
                'role' => $actor?->role ?? 'unknown'
            ],
            'time' => now()
        ]);

        if($user->status == 'active'){
            $status = 'Approved';
        }else{
            $status = 'Rejected';
        }
        $data = [
            'sender_id' => $validated['assessor_id'],
            'sender_type' => 'Assessor '.$status,
            'receiver_id' => '1',
            'message' => $user->name.' Assessor '.$status,
            'is_read' => 0,
            'is_read_admin' => 0,
            'user_type' => 'assessor'
        ];

        Notification::insert($data);

        return response()->json([
            'message' => 'Assessor status updated successfully.',
            'status' => $user->status
        ]);
    }

    public function viewAssessor($id)
    {
        $assessor = Assessors::findOrFail($id);
       
        $educations = $assessor->educations()->orderBy('id', 'desc')->get();
        
        $experiences = $assessor->experiences()->orderBy('id', 'desc')->get();
        $trainingexperience = $assessor->trainingexperience()->orderBy('id', 'desc')->get();
        // echo "<pre>";
        // print_r($trainingexperience);exit;
        $additioninfos = AdditionalInfo::select('*')->where('user_id' , $id)->where('user_type','assessor')->get();
        $subscriptionPlans = PurchasedSubscription::select('subscription_plans.*','purchased_subscriptions.*')
                                                    ->where('purchased_subscriptions.user_id', $id)
                                                    ->where('purchased_subscriptions.user_type', 'trainer')
                                                    ->join('subscription_plans', 'purchased_subscriptions.subscription_plan_id', '=', 'subscription_plans.id')
                                                    ->get();
        return view('admin.assessors.view', compact('assessor', 'educations', 'experiences', 'trainingexperience','additioninfos','subscriptionPlans'));
    }


    public function updateAssessorStatus(Request $request)
    {
        $request->validate([
            'assessor_id' => 'required|exists:assessors,id',
            'status' => 'required|in:approved,rejected,superadmin_approved,superadmin_rejected',
            'reason' => 'nullable|string|max:1000',
        ]);

        $assessor = Assessors::findOrFail($request->assessor_id);
        $user = auth()->user();
        $previousStatus = $assessor->admin_status;
        $status = $request->status;

        // Role validation
        if ($user->role === 'superadmin' && !Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Invalid status for superadmin');
        } elseif ($user->role === 'admin' && Str::startsWith($status, 'superadmin_')) {
            return back()->with('error', 'Admins cannot perform superadmin actions');
        } elseif (!in_array($user->role, ['admin', 'superadmin'])) {
            Log::warning('Unauthorized mentor status update attempt', [
                'attempted_by' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                ],
                'assessor_id' => $assessor->id,
                'time' => now(),
            ]);
            return back()->with('error', 'Unauthorized action.');
        }

        // Update status and rejection reason
        $assessor->admin_status = $status;
        $assessor->rejection_reason = Str::endsWith($status, 'rejected') ? $request->reason : null;
        $assessor->save();

        // Log the update
        Log::info('assessor admin status updated', [
            'assessor' => [
                'id' => $assessor->id,
                'name' => $assessor->name,
                'email' => $assessor->email,
                'previous_status' => $previousStatus,
                'new_status' => $status,
                'rejection_reason' => $assessor->rejection_reason,
            ],
            'updated_by' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
            ],
            'time' => now(),
        ]);

        // Send email if rejected
        if (Str::endsWith($status, 'rejected') && $request->filled('reason') && $assessor->email) {
            Mail::html('
                <!DOCTYPE html>
                <html>
                <head><meta charset="UTF-8"><title>Application Rejected – Talentrek</title>
                <style>
                    body { font-family: Arial, sans-serif; background-color: #f6f8fa; padding: 20px; color: #333; }
                    .container { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }
                    .header { text-align: center; margin-bottom: 20px; }
                    .footer { font-size: 12px; text-align: center; color: #999; margin-top: 30px; }
                    .reason { background-color: #ffe6e6; border-left: 4px solid #dc3545; padding: 10px 15px; margin: 15px 0; }
                </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h2>Application Update – <span style="color:#dc3545;">Rejected</span></h2>
                        </div>
                        <p>Hi <strong>' . e($assessor->name ?? $assessor->email) . '</strong>,</p>
                        <p>We regret to inform you that your application on <strong>Talentrek</strong> has been rejected.</p>
                        <div class="reason"><strong>Reason:</strong> ' . e($request->reason) . '</div>
                        <p>If you believe this was a mistake, contact <a href="mailto:support@talentrek.com">support@talentrek.com</a>.</p>
                        <p>Thank you,<br><strong>The Talentrek Team</strong></p>
                    </div>
                    <div class="footer">© ' . date('Y') . ' Talentrek. All rights reserved.</div>
                </body>
                </html>
            ', function ($message) use ($assessor) {
                $message->to($assessor->email)->subject('Application Rejected – Talentrek');
            });
        }

        return back()->with('success', 'Status updated successfully.');
    }




    public function viewAssessorBookingSession($id)
    {
        $bookingSessions = BookingSession::select('jobseeker_saved_booking_session.*', 'assessors.name as coach_name', 'assessors.email as coach_email','jobseekers.name as jobseeker_name', 'jobseekers.email as jobseeker_email','booking_slots.start_time', 'booking_slots.end_time','booking_slots.*','jobseeker_saved_booking_session.status as booking_status','jobseeker_saved_booking_session.id as booking_id')
                                ->join('assessors', 'jobseeker_saved_booking_session.user_id', '=', 'assessors.id')
                                ->join('jobseekers', 'jobseeker_saved_booking_session.jobseeker_id', '=', 'jobseekers.id')
                                ->join('booking_slots', 'jobseeker_saved_booking_session.booking_slot_id', '=', 'booking_slots.id')
                                ->where('jobseeker_saved_booking_session.user_id', $id)
                                ->where('jobseeker_saved_booking_session.user_type', 'assessor')
                                ->get();
        return view('admin.assessors.booking-session', compact('bookingSessions'));
    }

    public function showActivityLog()
    {
        $logPath = storage_path('logs/laravel.log');

        if (!File::exists($logPath)) {
            return view('admin.logs', ['logs' => []]);
        }

        $lines = File::lines($logPath)->toArray();

       $filteredLogs = collect($lines)
        ->filter(function ($line) {
            return Str::contains($line, [
                'Admin login successful',
                'Admin logged out',
                'Jobseekers assigned to admin',
                'Jobseeker status updated',
                'Jobseeker admin status updated',
                'Recruiter status updated',
                'Recruiter admin status updated',
            ]);
        })

        ->map(function ($line) {
            preg_match('/^\[(.*?)\] (\w+)\.(\w+): (.+)$/', $line, $matches);

            if (empty($matches)) {
                return null;
            }

            $timestamp = $matches[1] ?? '';
            $level = strtoupper($matches[2] ?? '');
            $message = $matches[3] ?? '';
            $rawData = $matches[4] ?? '';

            // Split message and data if merged
            if (Str::contains($rawData, '{')) {
                $parts = explode('{', $rawData, 2);
                $messageText = trim($parts[0]);
                $jsonString = '{' . ($parts[1] ?? '');
            } else {
                $messageText = $rawData;
                $jsonString = '{}';
            }

            // Remove slashes and decode
            $cleanedJson = stripslashes($jsonString);
            $decoded = json_decode($cleanedJson, true);

            return [
                'timestamp' => $timestamp,
                'level' => $level,
                'message' => $messageText,
                'data' => $decoded ?? $cleanedJson,
            ];
        })
        ->filter()
        ->reverse()
        ->values();


        return view('admin.logs', ['logs' => $filteredLogs]);
    }


    public function profile()
    {
        $user = Auth::user();

        if (!in_array($user->role, ['admin', 'superadmin'])) {
            abort(403, 'Unauthorized');
        }

        return view('admin.profile', [
            'user' => $user,
            'type' => $user->role
        ]);
    }


    public function updateAdminProfile(Request $request, $id)
    {
        $user = Admin::findOrFail($id);

        $request->validate([
            'name' => 'nullable|string|max:255',
            'email' => 'required|email|max:191|unique:admins,email,' . $id,
            'phone' => 'nullable|string',
            'notes' => 'nullable|string',
            'status' => 'required|in:active,inactive',
        ]);

        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'notes' => $request->notes,
            'status' => $request->status,
        ]);

        return redirect()->back()->with('success', 'Profile updated successfully.');
    }

    public function coupons()
    {
        $coupons = Coupon::latest()->paginate(10); // you can change per-page
        return view('admin.coupons.index', compact('coupons'));
    }

    public function createCoupon()
    {
        return view('admin.coupons.create');
    }

    public function storeCoupon(Request $request)
    {
        $request->validate([
            'code'           => 'required|unique:coupons,code',
            'discount_type'  => 'required|in:percentage,fixed',
            'discount_value' => 'required|numeric|min:0',
            'valid_from'     => 'nullable|date',
            'valid_to'       => 'nullable|date|after_or_equal:valid_from',
            'is_active'      => 'boolean',
            'is_private'     => 'nullable|string', // Accept yes or null
        ]);

        $data = $request->all();
        // Set default value: 'yes' if checked, 'no' if unchecked
        $data['is_private'] = $request->has('is_private') ? 'yes' : 'no';

        Coupon::create($data);

        return redirect()->route('admin.coupons.coupons')
                        ->with('success', 'Coupon created successfully.');
    }



   
    public function editCoupon($id)
    {
        $coupon = Coupon::findOrFail($id);
        return view('admin.coupons.edit', compact('coupon'));
    }

   
    public function updateCoupon(Request $request, $id)
    {
        $coupon = Coupon::findOrFail($id);

        $request->validate([
            'code'           => 'required|unique:coupons,code,' . $coupon->id,
            'discount_type'  => 'required|in:percentage,fixed',
            'discount_value' => 'required|numeric|min:0',
            'valid_from'     => 'nullable|date',
            'valid_to'       => 'nullable|date|after_or_equal:valid_from',
            'is_active'      => 'boolean',
            'is_private'     => 'nullable|string', // Accept 'yes' or null
        ]);

        $data = $request->all();
        // Set default value: 'yes' if checked, 'no' if unchecked
        $data['is_private'] = $request->has('is_private') ? 'yes' : 'no';

        $coupon->update($data);

        return redirect()->route('admin.coupons.coupons')
                        ->with('success', 'Coupon updated successfully.');
    }


    public function destroyCoupon($id)
    {
        $coupon = Coupon::findOrFail($id);
        $coupon->delete();

        return redirect()->route('admin.coupons.coupons')
                         ->with('success', 'Coupon deleted successfully.');
    }


    /**
     * Display a listing of the taxations.
     */
    public function taxations()
    {
        $taxations = Taxation::latest()->paginate(10);
        return view('admin.taxations.index', compact('taxations'));
    }

    /**
     * Show the form for creating a new taxation.
     */
    public function createTax()
    {
        return view('admin.taxations.create');
    }

    /**
     * Store a newly created taxation in storage.
     */
    public function showTaxations($type)
    {
        // Normalize type (make first letter uppercase for consistency)
        $type = ucfirst(strtolower($type));
        // Pass data to view
        return view('admin.taxations.view', compact('type'));
    }

    /**
     * Show the form for editing the specified taxation.
     */
    public function editTax($id)
    {
        $taxation = Taxation::findOrFail($id);
        return view('admin.taxations.edit', compact('taxation'));
    }

    /**
     * Update the specified taxation in storage.
     */
    public function updateTax(Request $request)
    {
        $request->validate([
            'user_type' => 'required|string|in:mentor,trainer,assessor,coach,subscription',
            'rate'      => 'required|numeric|min:0',
        ]);

        $userType = strtolower($request->input('user_type'));
        $rate     = $request->input('rate');

        // Map user types to setting fields
        $fieldMap = [
            'trainer'       => 'trainingMaterialTax',
            'mentor'        => 'mentorTax',
            'assessor'      => 'assessorTax',
            'coach'         => 'coachTax',
            'subscription'  => 'subscriptionTax'
        ];

        if (isset($fieldMap[$userType])) {
            // Get settings row (always only 1 row)
            $settings = Setting::first();
            if (!$settings) {
                $settings = Setting::create(); // create empty row if not exists
            }

            // Update only the required field
            $settings->{$fieldMap[$userType]} = $rate;
            $settings->save();
        }

        return redirect()
            ->route('admin.taxations.taxations')
            ->with('success', ucfirst($userType) . ' taxation updated successfully!');
    }





    /**
     * Remove the specified taxation from storage.
     */
    public function destroyTax($id)
    {
        $taxation = Taxation::findOrFail($id);
        $taxation->delete();

        return redirect()->route('admin.taxations.taxations')
                         ->with('success', 'Taxation deleted successfully.');
    }

   


public function downloadResume($id)
{
    require_once base_path('dompdf/autoload.inc.php');

    $jobseeker = Jobseekers::findOrFail($id);
    $educations = $jobseeker->educations()->get();
    $experiences = $jobseeker->experiences()->get();
    $skills = $jobseeker->skills()->get();

    $profilePic = DB::table('additional_info')
        ->where('user_id', $id)
        ->where('user_type', 'jobseeker')
        ->where('doc_type', 'profile_picture')
        ->value('document_path');

    if ($profilePic && !str_starts_with($profilePic, 'http')) {
        $profilePic = url($profilePic);
    }

    $certificates = DB::table('jobseeker_assessment_status as jas')
        ->join('training_materials as t', 'jas.material_id', '=', 't.id')
        ->leftJoin('trainers as tr', 't.trainer_id', '=', 'tr.id')
        ->select('t.training_title as course_name', 'tr.name as trainer_name', 'jas.created_at as completion_date')
        ->where('jas.jobseeker_id', $id)
        ->where('jas.submitted', 1)
        ->get();

    $template = DB::table('resumes_format')->first();
    if (!$template || empty($template->resume)) {
        return back()->with('error', 'Resume template not found.');
    }

    $html = Blade::render($template->resume, [
        'user' => $jobseeker,
        'educations' => $educations,
        'experiences' => $experiences,
        'skills' => $skills,
        'certificates' => $certificates,
        'profilePic' => $profilePic,
    ]);

    $options = new \Dompdf\Options();
    $options->set('isRemoteEnabled', true);
    $options->set('tempDir', storage_path('app/dompdf'));
    $options->set('chroot', public_path());

    $dompdf = new \Dompdf\Dompdf($options);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    return response($dompdf->output(), 200)
        ->header('Content-Type', 'application/pdf')
        ->header('Content-Disposition', "attachment; filename=Resume-{$jobseeker->name}.pdf");
}






public function viewCertificate($jobseeker_id, $material_id)

{

    require_once base_path('dompdf/autoload.inc.php');



    $user = Jobseekers::findOrFail($jobseeker_id);



    $template = CertificateTemplate::first();

    if (!$template) {

        return back()->with('error', 'Certificate template not found.');

    }



    $course = DB::table('training_materials as t')

        ->leftJoin('trainers as tr', 't.trainer_id', '=', 'tr.id')

        ->select('t.*', 'tr.name as trainer_name')

        ->where('t.id', $material_id)

        ->first();



    if (!$course) {

        return back()->with('error', 'Course not found.');

    }



    $userAssessment = DB::table('jobseeker_assessment_status')

        ->where('jobseeker_id', $user->id)

        ->where('material_id', $material_id)

        ->first();



    $completionDate = $userAssessment->created_at ?? now();

    $certificateId = 'T' . str_pad($material_id, 5, '0', STR_PAD_LEFT);



    $path = base_path('asset/images/Talentrek-Certificate-blank.png');

    if (!file_exists($path)) {
        return back()->with('error', 'Certificate background image not found.');
    }

   
    $type = pathinfo($path, PATHINFO_EXTENSION);

   
    $data = file_get_contents($path);

    
    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);





    $placeholders = [

        '{{ $user_name }}'         => $user->name,

        '{{ $certificate_title }}' => 'CERTIFICATE OF COMPLETION',

        '{{ $course_title }}'      => $course->training_title,

        '{{ $trainer_name }}'      => $course->trainer_name ?? 'Trainer',

        '{{ $course_duration }}'   => $course->total_duration ?? 'N/A',

        '{{ $completion_date }}'   => \Carbon\Carbon::parse($completionDate)->format('d M, Y'),

        '{{ $certificate_id }}'    => $certificateId,

        '{{ $conducted_by }}'      => 'Talentrek',

        '{{ $bg_image }}'          => $base64,

    ];



    $html = str_replace(array_keys($placeholders), array_values($placeholders), $template->template_html);



    // ✅ Generate PDF inline (no download)

    $dompdf = new Dompdf();

    $dompdf->loadHtml($html);

    $dompdf->setPaper('A4', 'landscape');

    $dompdf->render();



    return response($dompdf->output(), 200)

        ->header('Content-Type', 'application/pdf')

        ->header('Content-Disposition', 'inline; filename=Certificate-' . $user->name . '.pdf');

}





    public function expat()
    {   
        $admin = Auth::guard('admin')->user();
        $adminId = $admin->id;
        // If the user is a superadmin, show all jobseekers
        if ($admin->role === 'superadmin') {
            $expats = Jobseekers::orderBy('id', 'desc')->where('role','expat')
                                    ->get();
        } else {
            // Else show only expats assigned to this admin
            $expats = Jobseekers::where('assigned_admin', $adminId)
                                    ->orderBy('id', 'desc')
                                    ->where('role','expat')
                                    ->get();
        }

        $admins = Admin::where('role', 'admin')->get();

        return view('admin.expat.index', compact('expats', 'admins'));
    }


    public function expatChangeStatus(Request $request)
    {
        $validated = $request->validate([
            'expat_id' => 'required|exists:jobseekers,id',
            'status' => 'required|in:active,inactive',
            'reason' => 'nullable|string|max:1000'
        ]);

        $user = Jobseekers::findOrFail($validated['expat_id']);
        $oldStatus = $user->status;
        $oldReason = $user->inactive_reason;

        $user->status = $validated['status'];

        if ($validated['status'] === 'inactive' && isset($validated['reason'])) {
            $user->inactive_reason = $validated['reason'];
        } else {
            $user->inactive_reason = null;
        }

        $user->save();

        // Actor performing the change
        $actor = auth()->user();

        // Logging the change
        Log::info('Expat status updated', [
            'jobseeker' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email ?? null,
                'old_status' => $oldStatus,
                'new_status' => $user->status,
                'old_reason' => $oldReason,
                'new_reason' => $user->inactive_reason
            ],
            'changed_by' => [
                'id' => $actor?->id ?? null,
                'name' => $actor?->name ?? 'System',
                'email' => $actor?->email ?? 'system',
                'role' => $actor?->role ?? 'unknown'
            ],
            'time' => now()
        ]);

        if($user->status == 'active'){
            $status = 'Approved';
        }else{
            $status = 'Rejected';
        }
        $data = [
            'sender_id' => $validated['expat_id'],
            'sender_type' => 'Expat '.$status,
            'receiver_id' => '1',
            'message' => $user->name.' Expat '.$status,
            'is_read' => 0,
            'is_read_admin' => 0,
            'user_type' => 'expat'
        ];

        Notification::insert($data);

        return response()->json([
            'message' => 'Expat status updated successfully.',
            'status' => $user->status
        ]);
    }


    public function expatView($id)
    {
        $expat = Jobseekers::findOrFail($id);
        $educations = $expat->educations()->orderBy('id', 'desc')->get();
        $experiences = $expat->experiences()->orderBy('id', 'desc')->get();
        $skills = $expat->skills()->orderBy('id', 'desc')->get();
        $additioninfos = AdditionalInfo::select('*')->where('user_id' , $id)->where('user_type','expat')->get();
        $subscriptionPlans = PurchasedSubscription::select('subscription_plans.*','purchased_subscriptions.*')
                                                    ->where('purchased_subscriptions.user_id', $id)
                                                    ->where('purchased_subscriptions.user_type', 'expat')
                                                    ->join('subscription_plans', 'purchased_subscriptions.subscription_plan_id', '=', 'subscription_plans.id')
                                                    ->get();
        $certificates = DB::table('jobseeker_assessment_status as jas')
            ->join('training_materials as t', 'jas.material_id', '=', 't.id')
            ->leftJoin('trainers as tr', 't.trainer_id', '=', 'tr.id')
            ->select(
                't.training_title as course_name',
                'jas.created_at as completion_date',
                'jas.material_id' // ✅ yeh add karo
            )
            ->where('jas.jobseeker_id', $id)
            ->where('jas.submitted', 1)
            ->get();

        // echo "<pre>";                                         
        // print_r($certificates); die;    
        return view('admin.expat.view', compact('expat', 'experiences', 'educations', 'skills','additioninfos','subscriptionPlans', 'certificates'));
    }
}
