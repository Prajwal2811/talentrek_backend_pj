$(function () {
    //CKEditor
    CKEDITOR.replace('ckeditor.html');
    CKEDITOR.config.height = 300;
  
});